/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_getmed;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Khulood Alyaf3Y
 */
public class Notfcat_pharmacistController implements Initializable {

    /**
     * Initializes the controller class.
     */
        @FXML
    private AnchorPane notfc_pharm;

    @FXML
    private AnchorPane pane2;

    @FXML
    private Label show_tiltel;

    @FXML
    private ImageView back;

    @FXML
    private AnchorPane new_mwd_insert;

    @FXML
    private Label label_tiltel;

    @FXML
    private AnchorPane accepet_premation;

    @FXML
    private Label label_tiltel1;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }  
    
    
    
     @FXML
    void user_move(MouseEvent e) throws IOException {
        
        
            Parent acceptParent =FXMLLoader.load(getClass().getResource("accept_new_med.fxml"));
      Scene acceptScene=new Scene(acceptParent); 
      
   
     Stage window = (Stage)((Node)e.getSource()).getScene().getWindow();
     
     window.setScene(acceptScene);

    }
    
}
