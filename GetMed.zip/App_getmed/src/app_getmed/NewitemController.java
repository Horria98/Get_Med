/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_getmed;

import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javax.imageio.ImageIO;
import static javax.swing.Spring.height;
import static javax.swing.Spring.width;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 * FXML Controller class
 *
 * @author ghaida..
 */
public class NewitemController implements Initializable {


    @FXML
    private Rectangle imgmed;

    @FXML
    private Label namemed;
    
    private medicine meds=new medicine();
    Infopill1Controller n;
    
    private Stage stage;
    private Scene scene;
    private Parent root;
    MyListener3 myListener3;
    private byte[] buffer ;
    @FXML
    private AnchorPane GET_MED;
   
    public void setData(medicine med,MyListener3 myListener) throws FileNotFoundException, IOException{
        this.meds=med;
        this.myListener3=myListener;
       namemed.setText(med.getCompany_name());
       FileOutputStream fos;
            fos = new FileOutputStream("output.jpg");
            fos.write(med.getPhoto());
            fos.close();
            ImagePattern adminImagePattern = new ImagePattern(new Image("file:output.jpg"));
            imgmed.setFill(adminImagePattern);

    }

    @FXML
    void get_med(MouseEvent event) throws IOException {
        
         System.out.println(meds.getPrescription());
         
      if(meds.getPrescription().equals("no")){
             
        FXMLLoader  loader= new FXMLLoader(getClass().getResource("get_med.fxml"));
        
          root=loader.load();
          
         Get_medController get_med=loader.getController();
          get_med.set_information(meds);
       
       stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
      }
        
        else {
        
       FXMLLoader  loader= new FXMLLoader(getClass().getResource("get_med_prem.fxml"));
        
          root=loader.load();
          
         Get_med_premController get_med=loader.getController();
          get_med.set_information_pre(meds);
       
       stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
                }
        
        }   
        
        
        
        
        
        

    
    
 
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
//        Session session1 = HibernateUtil.getSessionFactory().openSession();
//        List<medicine> med_list = null;
//        String queryStr = "from medicine";
//        Query query = session1.createQuery(queryStr);
//        med_list =  query.list();
//        session1.close();
//        for(medicine u: med_list){
//            if (u.getId() == meds.getId()){
//                meds.setPhoto(u.getPhoto());
//                System.out.println(u.getPhoto());
//            FileOutputStream fos;
//            try {
//                fos = new FileOutputStream("output.jpg");
//                fos.write(u.getPhoto());
//                fos.close();
//            } catch (IOException e) { }
//        ImagePattern adminImagePattern = new ImagePattern(new Image("file:output.jpg"));
//        imgmed.setFill(adminImagePattern);

//            }
//        }
        
    }    
    
}
