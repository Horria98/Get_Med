/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_getmed;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class Get_med_ex3Controller implements Initializable{

    @FXML
    private Label company_name;

    @FXML
    private Label exipation_date;

    @FXML
    private Label opening_date;

    @FXML
    private Label life_after_opening;

    @FXML
    private Label quantity;

    @FXML
    private Label scientific_name;

    @FXML
    private Button get;

    @FXML
    private ImageView image;

    
    
     String name="Ahmad Ali";
     String phone="0544332672";
     String premation="yes";
    
    
    @FXML
    void get_med2(ActionEvent e) throws IOException {
        
        
        
        
        if(premation=="yes"){
            
       FXMLLoader loader= new FXMLLoader(getClass().getResource("get_med_prem.fxml"));
        
         Parent root=loader.load();
          
         Get_med_premController get_med=loader.getController();
        
      // get_med.set_information_pre(scientific_name.getText(),company_name.getText(),opening_date.getText(),
       //xipation_date.getText(),quantity.getText(),life_after_opening.getText());
       
     
        
      Scene get_Scene=new Scene(root); 
      
   
     Stage window = (Stage)((Node)e.getSource()).getScene().getWindow();
     
     window.setScene(get_Scene);
    }
    
    
    else{


    FXMLLoader loader= new FXMLLoader(getClass().getResource("get_med.fxml"));
        
         Parent root=loader.load();
          
        Get_medController get_med=loader.getController();
        
      // get_med.set_information(scientific_name.getText(),company_name.getText(),opening_date.getText(),
      // exipation_date.getText(),quantity.getText(),life_after_opening.getText(),name,phone);
       
     
        
      Scene get_Scene=new Scene(root); 
      
   
     Stage window = (Stage)((Node)e.getSource()).getScene().getWindow();
     
     window.setScene(get_Scene);
    }

        

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
     
    }
           @FXML
    void profilePage(MouseEvent event) throws IOException {
 Parent aboutParent =FXMLLoader.load(getClass().getResource("profile.fxml"));
      Scene aboutScene=new Scene(aboutParent); 
      
   
     Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
     
     window.setScene(aboutScene);
    }
  

   
   @FXML
    void homePage(MouseEvent event) throws IOException {

     Parent aboutParent =FXMLLoader.load(getClass().getResource("Homepage.fxml"));
      Scene aboutScene=new Scene(aboutParent); 
      
   
     Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
     
     window.setScene(aboutScene);
    } 
    
    
    @FXML
    void insertPage(MouseEvent event) throws IOException {
 Parent aboutParent =FXMLLoader.load(getClass().getResource("newMedication.fxml"));
      Scene aboutScene=new Scene(aboutParent); 
      
   
     Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
     
     window.setScene(aboutScene);
    }
}

