/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_getmed;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 * FXML Controller class
 *
 * @author horre
 */
public class NewPassController implements Initializable {

    /**
     * Initializes the controller class.
     */
    
    public PasswordField txt_hide_Password;
    public TextField txt_show_passwod;
    public ImageView openEye;
    public ImageView closeEye;
    String password;
    @FXML
    private Label label1;
    @FXML
    private TextField email;
    
    public  void initialize(){
        txt_show_passwod.setVisible(false);
        openEye.setVisible(false);
    }
    @FXML
    public void hidePasswordOnAction(KeyEvent keyEvent) {
        password=txt_hide_Password.getText();
        txt_show_passwod.setText(password);
    }
    @FXML
    public void showPasswordOnAction(KeyEvent keyEvent) {
        password=txt_show_passwod.getText();
        txt_hide_Password.setText(password);
    }
    @FXML
    public void open_Eye_ClickOnAction(MouseEvent mouseEvent) {
        txt_show_passwod.setVisible(false);
        openEye.setVisible(false);
        closeEye.setVisible(true);
        txt_hide_Password.setVisible(true);
    }
    @FXML
    public void close_Eye_Click_OnAction(MouseEvent mouseEvent) {
        txt_show_passwod.setVisible(true);
        openEye.setVisible(true);
        closeEye.setVisible(false);
        txt_hide_Password.setVisible(false);
    }

    public PasswordField txt_hide_Password2;
    public TextField txt_show_passwod2;
    public ImageView openEye2;
    public ImageView closeEye2;
    String password2;    
        public  void initialize2(){
        txt_show_passwod2.setVisible(false);
        openEye2.setVisible(false);
    }
    @FXML
    public void hidePasswordOnAction2(KeyEvent keyEvent) {
        password2=txt_hide_Password2.getText();
        txt_show_passwod2.setText(password2);
    }
    @FXML
    public void showPasswordOnAction2(KeyEvent keyEvent) {
        password2=txt_show_passwod2.getText();
        txt_hide_Password2.setText(password2);
    }
    @FXML
    public void open_Eye_ClickOnAction2(MouseEvent mouseEvent) {
        txt_show_passwod2.setVisible(false);
        openEye2.setVisible(false);
        closeEye2.setVisible(true);
        txt_hide_Password2.setVisible(true);
    }
    @FXML
    public void close_Eye_Click_OnAction2(MouseEvent mouseEvent) {
        txt_show_passwod2.setVisible(true);
        openEye2.setVisible(true);
        closeEye2.setVisible(false);
        txt_hide_Password2.setVisible(false);
    }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    } 
    
    private Stage stage;
    private Scene scene;
    private Parent root;
    
    @FXML
    public void toLogin(ActionEvent event) throws IOException {
        if (txt_hide_Password.getText().isEmpty()||txt_hide_Password2.getText().isEmpty())
            {
                label1.setVisible(true);
            }else if ( password.length() < 8 )
            {
                label1.setText("Password length should be Exceed 8 digits");
                label1.setVisible(true);
                
            }else if (password.equals(password2)) {
                boolean flag = false;
                            Session session1 = HibernateUtil.getSessionFactory().openSession();
                            List<user_info> user_list = null;
                            String queryStr = "from user_info";
                            Query query = session1.createQuery(queryStr);
                            user_list =  query.list();
                            session1.close();
                            for(user_info u: user_list){
                                //if user found 
                                if(u.getEmail().equals(email.getText())){ 
                                    flag =true;
                                    Session session2 = HibernateUtil.getSessionFactory().openSession();
                                    session2.beginTransaction();
                                    u.setPass(txt_hide_Password.getText());
                                    session2.update(u);
                                    session2.getTransaction().commit();
                                    session2.close();

                                    Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
                                    stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                                    scene = new Scene(root);
                                    stage.setScene(scene);
                                    stage.show();
                                    }
                            }
                            if (flag == false){
                                label1.setText("email not found in database");
                                label1.setVisible(true);
                            }                        
            }else
            {
                label1.setText("Password not equal");
                label1.setVisible(true);
            }
        }
    
}
