/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_getmed;

import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 * FXML Controller class
 *
 * @author Khulood Alyaf3Y
 */
public class Accept_new_med_Controller implements Initializable {


    @FXML
    private ScrollPane scrollpan_notfaction;

    @FXML
    private VBox vbox_notf;

    @FXML
    private AnchorPane prem_datils;

    @FXML
    private AnchorPane pane21;
    @FXML
    private AnchorPane imagePan;

  

    @FXML
    private Text del;


    @FXML
    private Text text_name;

    @FXML
    private Text text_phone;


    @FXML
    private Label lb_name_user;
    @FXML
    private ScrollPane scrollpan_not_accpet;
    @FXML
    private Button btBack;
    @FXML
    private Button btBack1;
    @FXML
    private Button btBack2;
    @FXML
    private ImageView accept;
    @FXML 
    private ImageView delete;
   
    String name;
    String med;
    String date;
    String time;
    String phone;
    
    List<prescription> pr_list =new ArrayList();
    
    prescription pImage = new prescription();
    


    public ScrollPane getScrollpan_not_accpet() {
        return scrollpan_not_accpet;
    }

    public VBox getVbox_notf() {
        return vbox_notf;
    }

    public String getName() {
        return name;
    }

    public String getMed() {
        return med;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public MyLestiner2 getMylitsener2() {
        return mylitsener2;
    }
    
   private MyLestiner2 mylitsener2;

    public void setScrollpan_not_accpet(ScrollPane scrollpan_not_accpet) {
        this.scrollpan_not_accpet = scrollpan_not_accpet;
    }

    public void setVbox_notf(VBox vbox_notf) {
        this.vbox_notf = vbox_notf;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setMed(String med) {
        this.med = med;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setMylitsener2(MyLestiner2 mylitsener2) {
        this.mylitsener2 = mylitsener2;
    }
    
    
   @Override
    public void initialize(URL url, ResourceBundle rb) {
          
        Session session3 = HibernateUtil.getSessionFactory().openSession();
                List<prescription> p_list = null;
                String queryStr3 = "from prescription";
                Query query3 = session3.createQuery(queryStr3);
                p_list =  query3.list();
                session3.close();
                for(prescription p: p_list){
                    prescription pr = new prescription();
                  if (p.getAccept().equals("no")){
                      pr.setAdmin_num(p.getAdmin_num());
                      pr.setUser_num(p.getUser_num());
                      pr.setMedicine_id(p.getMedicine_id());
                      pr.setPhoto(p.getPhoto());
                      
                    pr_list.add(pr);
                  }
                    
                    
                }                   

         if(pr_list.size()>0){
          
       set_name(pr_list.get(0));
         
             mylitsener2=new MyLestiner2() {
                 @Override
                 public void onclickListener(prescription pre) {
                    set_name(pre);
                    prem_datils.setVisible(true);

                 }
             };  
      
     for(int i=0;i<pr_list.size();i++)
        {
     try {        
        FXMLLoader fxmlloader =new FXMLLoader();
        
        fxmlloader.setLocation(getClass().getResource("item_phrme.fxml"));
       
        AnchorPane pan_not;
        
             pan_not = fxmlloader.load();
       
        Item_phrmeController itemContrroler=fxmlloader.getController();
         
         itemContrroler.setData(pr_list.get(i),mylitsener2);
         
         vbox_notf.getChildren().add(pan_not);
         
        
       } catch (IOException ex) {
             Logger.getLogger(Accept_new_med_Controller.class.getName()).log(Level.SEVERE, null, ex);
         }
           
        }
         }
         
    }  
 
      
    public void set_name(prescription p){
              
        Session session1 = HibernateUtil.getSessionFactory().openSession();
        List<user_info> user_list = null;
        String queryStr = "from user_info";
        Query query = session1.createQuery(queryStr);
        user_list =  query.list();
        session1.close();
        for(user_info u: user_list){
            if (p.getUser_num().equals(u.getPhone_num())){
              
             lb_name_user.setText(u.getFull_name());
             text_name.setText(u.getFull_name());
             text_phone.setText(u.getPhone_num());
            } 
          }
    }
          
          
          
           @FXML
    void back(ActionEvent e) {

        prem_datils.setVisible(false);
        
    }
    
    
    @FXML
    void back_hmoe(ActionEvent e) throws IOException {

            
      Parent acceptParent =FXMLLoader.load(getClass().getResource("Admin_profile.fxml"));
      Scene acceptScene=new Scene(acceptParent); 
     Stage window = (Stage)((Node)e.getSource()).getScene().getWindow();    
     window.setScene(acceptScene);

    }
     private Stage stage;
    private Scene scene;
    private Parent root;
    @FXML
    private Rectangle prescription;
     @FXML
    void viewPresciption(MouseEvent e) throws IOException {

         prescription pr = new prescription();
     Session session3 = HibernateUtil.getSessionFactory().openSession();
        List<prescription> p_list = null;
        String queryStr3 = "from prescription";
        Query query3 = session3.createQuery(queryStr3);
        p_list =  query3.list();
        session3.close();
        for(prescription p: p_list){
            if (p.getUser_num().equals(text_phone.getText())){
                pr.setUser_num(p.getUser_num());
                pr.setAdmin_num(p.getAdmin_num());
                pr.setMedicine_id(p.getMedicine_id());
                pr.setAccept(p.getAccept());
                pr.setPhoto(p.getPhoto());
        FileOutputStream fos;
            fos = new FileOutputStream("output.jpg");
            fos.write(pr.getPhoto());
            fos.close();
            ImagePattern adminImagePattern = new ImagePattern(new Image("file:output.jpg"));
            prescription.setFill(adminImagePattern);
            
            imagePan.setVisible(true);
        }
        }
    }
    

    
    @FXML
    private void minimizeAccept(MouseEvent event) {
        accept.setFitHeight(accept.getFitHeight()-5);
        accept.setFitWidth(accept.getFitWidth()-5);
        accept.setTranslateX(accept.getTranslateX()+5);
    }

    @FXML
    private void enlargeAccept(MouseEvent event) {
        accept.setFitHeight(accept.getFitHeight()+5);
        accept.setFitWidth(accept.getFitWidth()+5);
        accept.setTranslateX(accept.getTranslateX()-5);
    }
    
     @FXML
    private void minimizeDelete(MouseEvent event) {
        delete.setFitHeight(delete.getFitHeight()-5);
        delete.setFitWidth(delete.getFitWidth()-5);
        delete.setTranslateX(delete.getTranslateX()+5);
    }

    @FXML
    private void enlargeDelete(MouseEvent event) {
        delete.setFitHeight(delete.getFitHeight()+5);
        delete.setFitWidth(delete.getFitWidth()+5);
        delete.setTranslateX(delete.getTranslateX()-5);
    }
    
     @FXML
    void backDet(ActionEvent event) throws IOException {

        imagePan.setVisible(false);

    }
    
    
    @FXML
    private void changeType(MouseEvent event) throws IOException {
        
        prescription pr = new prescription();
        Session session3 = HibernateUtil.getSessionFactory().openSession();
        List<prescription> p_list = null;
        String queryStr3 = "from prescription";
        Query query3 = session3.createQuery(queryStr3);
        p_list =  query3.list();
        session3.close();
        for(prescription p: p_list){
            if (p.getUser_num().equals(text_phone.getText())){            
            Session session2 = HibernateUtil.getSessionFactory().openSession();
                session2.beginTransaction();
                p.setAccept("yes");
                session2.update(p);
                session2.getTransaction().commit();
                session2.close();

                Parent root = FXMLLoader.load(getClass().getResource("Admin_profile.fxml"));
                stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
            }
        }  
    }
    
    @FXML
    private void deleted(MouseEvent event) throws IOException {
        prescription pr = new prescription();
        Session session3 = HibernateUtil.getSessionFactory().openSession();
        List<prescription> p_list = null;
        String queryStr3 = "from prescription";
        Query query3 = session3.createQuery(queryStr3);
        p_list =  query3.list();
        session3.close();
        for(prescription p: p_list){
            if (p.getUser_num().equals(text_phone.getText())){            
            Session session2 = HibernateUtil.getSessionFactory().openSession();
                session2.beginTransaction();
                session2.delete(p);
                session2.getTransaction().commit();
                session2.close();

                Parent root = FXMLLoader.load(getClass().getResource("Admin_profile.fxml"));
                stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();  
    }
}
}
    
       
     @FXML
    private void minimizeback(MouseEvent event) {
        btBack.setPrefHeight(btBack.getPrefHeight()-5);
        btBack.setPrefWidth(btBack.getPrefWidth()-5);
        btBack.setTranslateX(btBack.getTranslateX()+5);
    }

    @FXML
    private void enlargeback(MouseEvent event) {
        btBack.setPrefHeight(btBack.getPrefHeight()+5);
        btBack.setPrefWidth(btBack.getPrefWidth()+5);
        btBack.setTranslateX(btBack.getTranslateX()-5);
    }
     @FXML
    private void minimizeback1(MouseEvent event) {
        btBack1.setPrefHeight(btBack1.getPrefHeight()-5);
        btBack1.setPrefWidth(btBack1.getPrefWidth()-5);
        btBack1.setTranslateX(btBack1.getTranslateX()+5);
    }

    @FXML
    private void enlargeback1(MouseEvent event) {
        btBack1.setPrefHeight(btBack1.getPrefHeight()+5);
        btBack1.setPrefWidth(btBack1.getPrefWidth()+5);
        btBack1.setTranslateX(btBack1.getTranslateX()-5);
    }
     @FXML
    private void minimizeback2(MouseEvent event) {
        btBack2.setPrefHeight(btBack2.getPrefHeight()-5);
        btBack2.setPrefWidth(btBack2.getPrefWidth()-5);
        btBack2.setTranslateX(btBack2.getTranslateX()+5);
    }

    @FXML
    private void enlargeback2(MouseEvent event) {
        btBack2.setPrefHeight(btBack2.getPrefHeight()+5);
        btBack2.setPrefWidth(btBack2.getPrefWidth()+5);
        btBack2.setTranslateX(btBack2.getTranslateX()-5);
    }
    }



