/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_getmed;

import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.event.EventType;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 *
 * @author Khulood Alyaf3Y
 */
public class NotfcatinContrroler implements Initializable {
    
    
    

/**
 * FXML Controller class
 *
 * @author Khulood Alyaf3Y
 */


    /**
     * Initializes the controller class.
     */
    
    
       @FXML
    private Button dont_yes;
     @FXML
    private Text del;
        @FXML
    private Text content;
    @FXML
    private ScrollPane scrollpan_notfaction;

    @FXML
    private VBox vbox_notfaction;

    @FXML
    private AnchorPane message_datils;

    @FXML
    private AnchorPane pane2;


    @FXML
    private Label lb_titel;

    @FXML
    private ImageView img_date;

    @FXML
    private Text text_date;

    @FXML
    private ImageView img_time;

    @FXML
    private Text text_time;

      @FXML
    private Text phone;
    
          @FXML
    private Text name;
     @FXML
    private Text namem;
          
      @FXML
    private Text text_phone;
    
          @FXML
    private Text text_name;      
    String permission;
  List<medicine> n_med=new ArrayList();
    int num;
    @FXML
    private Button back;
    @FXML
    private Button profil;
    @FXML
    private Button home;
    @FXML
    private Button insert;
    @FXML
    private Button back1;
    @FXML
    private Label show_tiltel;

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }
   List<Notfcation> not=new ArrayList();
   
 String name1="Ahmade" ;
  String phone1="05554444224";

String message;
String time;
String date;    

    public void setPermission(String permission) {
        this.permission = permission;
    }

    public String getPermission() {
        return permission;
    }



    public void setMessage(String message) {
        this.message = message;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getMessage() {
        return message;
    }

    public String getTime() {
        return time;
    }

    public String getDate() {
        return date;
    }
   
        
    
    
    private List<Notfcation> getData(String message,String date,String time){
    
    List<Notfcation> not=new ArrayList();
    
    Notfcation notfac=new Notfcation();
    
    
    notfac.setTitel(message);
    notfac.setDate(date);
    notfac.setTime(time);
 
    not.add(notfac);
    
      
  return  not; 
    }
    

    
  

    public void setImg_date(ImageView img_date) {
        this.img_date = img_date;
    }

    public void setText_date(Text text_date) {
        this.text_date = text_date;
    }

    public void setImg_time(ImageView img_time) {
        this.img_time = img_time;
    }

    public void setText_time(Text text_time) {
        this.text_time = text_time;
    }

    public void setLb_titel(Label lb_titel) {
        this.lb_titel = lb_titel;
    }

    public Label getLb_titel() {
        return lb_titel;
    }

    

    public ImageView getImg_date() {
        return img_date;
    }

    public Text getText_date() {
        return text_date;
    }

    public ImageView getImg_time() {
        return img_time;
    }

    public Text getText_time() {
        return text_time;
    }
 
    private MyListener mylitsener;
    
    @Override
     public void initialize(URL url, ResourceBundle rb) {
       

      // date of the day
           Date dated = new Date();
	SimpleDateFormat formatterd = new SimpleDateFormat("dd");
        SimpleDateFormat formatterm = new SimpleDateFormat("MMM");
         SimpleDateFormat formattery = new SimpleDateFormat("yyyy");
//	SimpleDateFormat formatterh = new SimpleDateFormat("HH");
//        SimpleDateFormat formattermm = new SimpleDateFormat("mm");
         String formattedDateStringd = formatterd.format(dated);
        String formattedDateStringm = formatterm.format(dated);
         String formattedDateStringy = formattery.format(dated);
//          String formattedDateStringh = formatterh.format(dated);
//         String formattedDateStringmm = formattermm.format(dated);
	//-------------------------------
            LocalDateTime currentDateTime = LocalDateTime.now();
          DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;
           String formattedDateTime = currentDateTime.format(formatter);
            String[]splitdata1=formattedDateTime.split("-");
           int year=Integer.parseInt(splitdata1[0]);
           int month=Integer.parseInt(splitdata1[1]);
         
        
        if(formattedDateStringd.equals("19")||formattedDateStringd.equals("29")){
         message="Donation";
        date=formattedDateStringd+"-"+month+"-"+formattedDateStringy;
//        time=formattedDateStringh+":"+formattedDateStringmm;;
        not.addAll(getData(message,date,time));
         
        }
//        message_datils.setVisible(false); 
//        
//            message="Accept the permission";
//        date="20-2-2020";
//        time="12:00PM";
//        not.addAll(getData(message,date,time));
//       
//        
//        
//           message="Accept the permission";
//        date="2-7-2020";
//        time="9:00PM";
//        not.addAll(getData(message,date,time));
      
        
       
        
//        retrieve
        
         medicine new_med=new medicine();
         Session session1 = HibernateUtil.getSessionFactory().openSession();
        List<medicine> listmed = null;
     
        String queryStr = "from medicine";
        Query query = session1.createQuery(queryStr);
        listmed =  query.list();
        session1.close();
   
       for( medicine m: listmed){ 
           date=m.getExp();
           
           String[]splitdata=date.split("-");
         
          int day1=Integer.parseInt(splitdata[0]);
          int month1=Integer.parseInt(splitdata[1]);
          int year1=Integer.parseInt(splitdata[2]);
       
         
            int aftmonth;
           if(String.valueOf(month).equals("12")){
            aftmonth=1;
           
              }
           else{
               aftmonth=month+1;
           }
           if(String.valueOf(month1).equals(String.valueOf(aftmonth))&&String.valueOf(day1).equals(formattedDateStringd)){
            
         message="Medicine expiry date";
         date=m.getExp();
         time="1:00AM";
         String n=m.getCompany_name();
          namem.setText(n);
               not.addAll(getData(message,date,time));
           
           }
           }
       
//      
//         for date of medicine
//        
//           
//           if(String.valueOf(month1).equals(String.valueOf(aftmonth))&&String.valueOf(day1).equals(formattedDateStringd)&&String.valueOf(year).equals(String.valueOf(year1))){
//           not.addAll(getData(message,date,time));
//          }
       
        
        
        if(not.size()>0){
          
         set_messge(not.get(0));
             mylitsener=new MyListener() {
                 @Override
                 public void onclickListener(Notfcation notfication) {
                     set_messge(notfication);
                      message_datils.setVisible(true);

                 }
             };      
        
        
        
        }
        try {  
        for(int i=0;i<not.size();i++)
        {
            num++;
        FXMLLoader fxmlloader =new FXMLLoader();
        
        fxmlloader.setLocation(getClass().getResource("item.fxml"));
        AnchorPane pan_not=fxmlloader.load();
           
        ItemContrroler itemContrroler=fxmlloader.getController();
         
         itemContrroler.setData(not.get(i),mylitsener);
         
         vbox_notfaction.getChildren().add(pan_not);
         
        }
        } catch (IOException ex) {
                Logger.getLogger(NotfcatinContrroler.class.getName()).log(Level.SEVERE, null, ex);
            }
//        
// 
     }
        public void set_messge(Notfcation notfac){
        
       lb_titel.setText(notfac.getTitel());     
            
            
         if(lb_titel.getText()=="Accept the permission") {  
      
               del.setText("Your prescription has been\n accepted You can get\n contact information");
         
               phone.setVisible(true);
               name.setVisible(true);
                namem.setVisible(false);
                 content.setVisible(true);
            text_name.setVisible(true);
               text_phone.setVisible(true);
               
               text_name.setText(name1);
               text_phone.setText(phone1);
               
               text_date.setText(notfac.getDate());
               text_time.setText(notfac.getTime());
               dont_yes.setVisible(false);
         }
         else  if(lb_titel.getText()=="Donation")
         {
         namem.setVisible(false);
            content.setVisible(false);
            text_name.setVisible(false);
               text_phone.setVisible(false);
               phone.setVisible(false);
               name.setVisible(false);
             del.setText("Do you want to donate a new\n medicine? ");
              text_date.setText(notfac.getDate());
               text_time.setText(notfac.getTime());
               dont_yes.setVisible(true);
             
         }
         else if(lb_titel.getText()=="Medicine expiry date")
         {
         del.setText(" There are 30 days left until the expiration date.\n\n\n\nthe name of medicine" );
              content.setVisible(false);
            text_name.setVisible(false);
               text_phone.setVisible(false);
               phone.setVisible(false);
               namem.setVisible(true);
            name.setVisible(false);
              text_date.setText(notfac.getDate());
               text_time.setText(notfac.getTime());
            dont_yes.setVisible(false);
         
         }
             
             }
        
        
    void back_notfcation(ActionEvent event) {

        
         message_datils.setVisible(false); 
        
    }
    
    @FXML
    void insertPage(ActionEvent event)  throws IOException {
 Parent aboutParent =FXMLLoader.load(getClass().getResource("newMedication.fxml"));
      Scene aboutScene=new Scene(aboutParent); 
      
   
     Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
     
     window.setScene(aboutScene);
    }
    
    @FXML
    public void Profile (ActionEvent event) throws IOException{
     Parent aboutParent =FXMLLoader.load(getClass().getResource("Profile.fxml"));
      Scene aboutScene=new Scene(aboutParent); 
      
   
     Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
     
     window.setScene(aboutScene);
    }

    @FXML
    private void minimizeback(MouseEvent event) {
        back.setPrefHeight(back.getPrefHeight()-5);
        back.setPrefWidth(back.getPrefWidth()-5);
        back.setTranslateX(back.getTranslateX()+5);
    }

    @FXML
    private void enlargeback(MouseEvent event) {
        back.setPrefHeight(back.getPrefHeight()+5);
        back.setPrefWidth(back.getPrefWidth()+5);
        back.setTranslateX(back.getTranslateX()-5);
    }

    

    @FXML
    private void enlargeback1(MouseEvent event) {
        back1.setPrefHeight(back1.getPrefHeight()+5);
        back1.setPrefWidth(back1.getPrefWidth()+5);
        back1.setTranslateX(back1.getTranslateX()-5);
    }
    @FXML
    private void minimizeback1(MouseEvent event) {
        back1.setPrefHeight(back1.getPrefHeight()-5);
        back1.setPrefWidth(back1.getPrefWidth()-5);
        back1.setTranslateX(back1.getTranslateX()+5);
    }

    @FXML
    private void homepage(ActionEvent event) throws IOException {
        
      Parent aboutParent =FXMLLoader.load(getClass().getResource("Homepage.fxml"));
      Scene aboutScene=new Scene(aboutParent); 
     Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();    
     window.setScene(aboutScene);
    }

    @FXML
    private void goBack(ActionEvent event) {
        
        message_datils.setVisible(false);
    }
    
    


}

    

