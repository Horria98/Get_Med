/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_getmed;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class Get_med_premController implements Initializable {

    @FXML
    private Text scientific_name;

    @FXML
    private Text company_name;

    @FXML
    private Text opening_date;

    @FXML
    private Text quantity;

    @FXML
    private Text shelf_life_after_opening;

    @FXML
    private Text exipation_date;

    @FXML
    private Button upload;
    @FXML
    private AnchorPane messageAccet;
    
      
    String pathe;
    @FXML
    private Button bt_save;
    @FXML
    private Label label1;
    private FileChooser filechooser = new FileChooser();
    private File filePath ;
    private byte[] buffer;
    
    
    private Stage stage;
    private Scene scene;
    private Parent root;
    
    int id ;
   
    
            
    @FXML
    void upload_file(ActionEvent event) throws FileNotFoundException {
        
          File selectedImage = filechooser.showOpenDialog(stage);
        if (selectedImage != null) {
            buffer = new byte[(int) selectedImage.length()];
            try {

                FileInputStream inputStream = new FileInputStream(selectedImage);
                inputStream.read(buffer);
                inputStream.close();
                
                setPathe(selectedImage.getAbsolutePath());
                label1.setText(selectedImage.getAbsolutePath());
                

            } catch (IOException e) {
                Alert error = new Alert(Alert.AlertType.ERROR);
                error.setTitle("Something went wrong");
                error.setHeaderText(null);
                error.setContentText("Try again");
                error.show();
            }
    }
    
     
    }
    void viewex1(MouseEvent event) {

        
        
    }
    String numOfAdmin ;
    @FXML
    void save_file(ActionEvent event) throws IOException {
                Session session = HibernateUtil.getSessionFactory().openSession();
                List<admin_info> admin_list = null;
                String queryStr = "from admin_info";
                Query query = session.createQuery(queryStr);
                admin_list =  query.list();
                session.close();
                for(admin_info a: admin_list){
                numOfAdmin = a.getPhone_number();
                }   
                Session session3 = HibernateUtil.getSessionFactory().openSession();
                List<user_info> user_list = null;
                String queryStr3 = "from user_info";
                Query query3 = session3.createQuery(queryStr3);
                user_list =  query3.list();
                session3.close();
                for(user_info u: user_list){                    
                if (userLogInNow.userLogIn.equals(u.getEmail())){
                
                    
                prescription p = new prescription();
                p.setUser_num(u.getPhone_num());
                p.setAdmin_num(numOfAdmin);
                p.setMedicine_id(id);
                p.setPhoto(buffer);
                p.setAccept("no");
                Session session2 = HibernateUtil.getSessionFactory().openSession();
                session2 = HibernateUtil.getSessionFactory().openSession();
                Transaction tx = session2.beginTransaction();
                session2.save(p);
                tx.commit();
                session2.close();
                
                messageAccet.setVisible(true);
                    
                }
                    
                }    
    }

    public void setPathe(String pathe) {
        this.pathe = pathe;
    }

    public String getPathe() {
        return pathe;
    }

    

    
      public void set_information_pre(medicine m){
        id = m.getId();
        scientific_name.setText(m.getMedical_name());  
        company_name.setText(m.getCompany_name());
        opening_date.setText(m.getOpening_date());
        exipation_date.setText(m.getExp());
        shelf_life_after_opening.setText(m.getExp_after_open());
        quantity.setText(m.getQuantity());
       
     
   }       
         

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        
        
    
  
    }
   
   
   @FXML
    void homePage(MouseEvent event) throws IOException {

     Parent aboutParent =FXMLLoader.load(getClass().getResource("Homepage.fxml"));
      Scene aboutScene=new Scene(aboutParent); 
      
   
     Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
     
     window.setScene(aboutScene);
    } 
    
  @FXML
    void toHome(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Homepage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
   
   
}
