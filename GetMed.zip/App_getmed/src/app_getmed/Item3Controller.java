/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_getmed;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author Khulood Alyaf3Y
 */
public class Item3Controller implements Initializable {

   
    private medicine med;
  
    MyListener3 myListener3;
    
    @FXML
    private AnchorPane new_mwd_insert;

    @FXML
    private Label name_med;

    @FXML
    void click_item(MouseEvent event) {

       myListener3.onclickListener(med);
    }
    @Override
    public void initialize(URL location, ResourceBundle resources) {
       
        
    }
   
    
 public void setDataMed(medicine m, MyListener3 mylitsener){
    
    this.med=m;
    this.myListener3=mylitsener;
    name_med.setText(m.getCompany_name());
   
 
    }

    
}
