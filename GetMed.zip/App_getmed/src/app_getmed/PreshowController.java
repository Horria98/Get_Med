/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_getmed;

import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 * FXML Controller class
 *
 * @author Khulood Alyaf3Y
 */
public class PreshowController implements Initializable {

    @FXML
    private ImageView back;
    @FXML
    private Rectangle prescription;
    
    private prescription pr;



    /**
     * Initializes the controller class.
     */
    
    public void setImage(prescription p){
   
    this.pr=p;
    pr.setPhoto(p.getPhoto());
    pr.setMedicine_id(p.getMedicine_id());
    Session session3 = HibernateUtil.getSessionFactory().openSession();
        List<prescription> p_list = null;
        String queryStr3 = "from prescription";
        Query query3 = session3.createQuery(queryStr3);
        p_list =  query3.list();
        session3.close();
        for(prescription u: p_list){
            if (u.getMedicine_id() == pr.getMedicine_id()){
                FileOutputStream fos;
        try {
            fos = new FileOutputStream("output.jpg");
            fos.write(u.getPhoto());
            fos.close();
        } catch (IOException e) {

        }
        ImagePattern adminImagePattern = new ImagePattern(new Image("file:output.jpg"));
        prescription.setFill(adminImagePattern);
            }
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        
        
    }
    
    @FXML
    void back_hmoe(MouseEvent e) throws IOException {

            
            Parent acceptParent =FXMLLoader.load(getClass().getResource("accept_new_med.fxml"));
      Scene acceptScene=new Scene(acceptParent); 
      
   
     Stage window = (Stage)((Node)e.getSource()).getScene().getWindow();
     
     window.setScene(acceptScene);

    }
    
     @FXML
    private void minimizeBack(MouseEvent event) {
        back.setFitHeight(back.getFitHeight()-5);
        back.setFitWidth(back.getFitWidth()-5);
        back.setTranslateX(back.getTranslateX()+5);

    }

    @FXML
    private void enlargeBack(MouseEvent event) {
        back.setFitHeight(back.getFitHeight()+5);
        back.setFitWidth(back.getFitWidth()+5);
        back.setTranslateX(back.getTranslateX()-5);
    }
    
}
