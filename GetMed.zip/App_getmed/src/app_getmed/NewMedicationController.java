 
package app_getmed;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class NewMedicationController implements Initializable {
      
 @FXML
    private AnchorPane messageAccet;
    
@FXML
    private TextField txScientificName;

    @FXML
    private TextField txCompanyName;

    @FXML
    private TextField txQuantity;

    @FXML
     private TextField txExpirationDate;

    @FXML
    private TextField txOpenDate;

    @FXML
    private TextField txExpirationDateAfterOpening;
    
    

    @FXML
    private Button back;

    @FXML
    private Button btInser;

    @FXML
    private Button btprofil;

    @FXML
    private Button bthome;

    @FXML
    private Button btinsertNew;
        
       @FXML
    private Label error;
    
  private user_info us = new user_info();
  
   
    String num;
    String date;
    @FXML
    private Button ok;
    @FXML
    private Label label_num;
  
   public void getName(user_info user){
       
        this.us = user ;
        us.setFull_name(user.getFull_name());
        System.out.println(us.getFull_name());
        us.setPhone_num(user.getPhone_num());
        System.out.println(us.getPhone_num());
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
     
        
    }    
     
    int id=0;
    
    @FXML
    public void changeScenesHomepage (ActionEvent event) throws IOException{
    Parent changeScenesHomepage = FXMLLoader.load(getClass().getResource("Homepage.fxml"));
    Scene HomepageScene =new Scene( changeScenesHomepage);
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    window.setScene(HomepageScene);
    window.show();
    }// change Scenes to Homepage
    
 
    @FXML
    public void changeScenesProfile (ActionEvent event) throws IOException{
    Parent changeScenesProfile  = FXMLLoader.load(getClass().getResource("profile.fxml"));
    Scene ProfileScene =new Scene(changeScenesProfile);
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    window.setScene(ProfileScene);
    window.show();
    }//change Scenes to Profile page
    
    public void changeScenesToInsert (ActionEvent event) throws IOException{
        String ScientificName=  txScientificName.getText();
        String CompanyName= txCompanyName.getText();
        String Quantity= txQuantity.getText();
        String ExpirationDate= txExpirationDate.getText();
        String OpenDate=txOpenDate.getText();
        String ExpirationDateAfterOpening=txExpirationDateAfterOpening.getText();
       FXMLLoader loader=new FXMLLoader(getClass().getResource("Insert.fxml"));   
     Parent changeScenesToinsert=loader.load(); 
     InsertController insertController=loader.getController();
  insertController.DisplayMedication(ScientificName, CompanyName, ExpirationDate, OpenDate, ExpirationDateAfterOpening, Quantity);
    
    //Parent changeScenesToinsert = FXMLLoader.load(getClass().getResource("Insert.fxml"));
    Scene insertScene =new Scene( changeScenesToinsert);
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    window.setScene(insertScene);
    window.show();
    }//change Scenes To Insert page 
    
    //هنا شوفي كيف تخلين الصورة تظهر لصفحة الوصفات الطبية 
  
    
         
     @FXML
    void homePage(MouseEvent event) throws IOException {

     Parent aboutParent =FXMLLoader.load(getClass().getResource("Homepage.fxml"));
      Scene aboutScene=new Scene(aboutParent); 
      
   
     Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
     
     window.setScene(aboutScene);
    } 
    
    
   
    @FXML
    void homePageAction(ActionEvent event) throws IOException {

    
     Parent aboutParent =FXMLLoader.load(getClass().getResource("Homepage.fxml"));
      Scene aboutScene=new Scene(aboutParent); 
      
   
     Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
     
     window.setScene(aboutScene);
    } 
    
    
    
      @FXML
    void insert_med(ActionEvent event) throws ParseException, IOException {
  
  if(txCompanyName.getText().isEmpty()&&txScientificName.getText().isEmpty()&&txQuantity.getText().isEmpty()&&txExpirationDate.getText()!=""&&
           txOpenDate.getText().isEmpty()&&txExpirationDateAfterOpening.getText().isEmpty()){
     error.setVisible(true);
             
          }
  
    else {
  
     medicine new_med=new medicine();
          Session session1 = HibernateUtil.getSessionFactory().openSession();
        List<medicine> listmed = null;
     
        String queryStr1 = "from medicine";
        Query query1 = session1.createQuery(queryStr1);
        listmed =  query1.list();
        session1.close();
        
        
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<admin_info> admin_list = null;
        String queryStr = "from admin_info";
        Query query = session.createQuery(queryStr);
        admin_list =  query.list();
        session.close();
        for(admin_info a: admin_list){
            num = a.getPhone_number();
            System.out.println(num);
        }
        
        // date of the day
           Date dated = new Date();
	SimpleDateFormat formatterd = new SimpleDateFormat("dd");
        SimpleDateFormat formatterm = new SimpleDateFormat("MMM");
         SimpleDateFormat formattery = new SimpleDateFormat("yyyy");
	SimpleDateFormat formatterh = new SimpleDateFormat("HH");
        SimpleDateFormat formattermm = new SimpleDateFormat("mm");
         String formattedDateStringd = formatterd.format(dated);
        String formattedDateStringm = formatterm.format(dated);
         String formattedDateStringy = formattery.format(dated);
          String formattedDateStringh = formatterh.format(dated);
         String formattedDateStringmm = formattermm.format(dated);
	//-------------------------------
            LocalDateTime currentDateTime = LocalDateTime.now();
          DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;
           String formattedDateTime = currentDateTime.format(formatter);
            String[]splitdata1=formattedDateTime.split("-");
           int year=Integer.parseInt(splitdata1[0]);
           int month=Integer.parseInt(splitdata1[1]);
           date=formattedDateStringd+"-"+month+"-"+formattedDateStringy;

       
        if(listmed.size()==0){
      medicine med=new medicine(); 
      med.setCompany_name(txCompanyName.getText());
      med.setMedical_name(txScientificName.getText());
      med.setQuantity(txQuantity.getText());
      med.setExp(txExpirationDate.getText());
      med.setOpening_date(txOpenDate.getText());
      med.setExp_after_open(txExpirationDateAfterOpening.getText());
      med.setId(++id);
      med.setType("non");
      med.setUser_num(us.getPhone_num());
      med.setAdmin_num(num);
      System.out.println(med.getUser_num());
       
      med.setInserted_date(date);
      //med.setReceived_date("16/9/2019");

     
       Session session2 = HibernateUtil.getSessionFactory().openSession();
        session2 = HibernateUtil.getSessionFactory().openSession();
        Transaction tx4 = session2.beginTransaction();
        session2.save(med);
        tx4.commit();
        session2.close();
        }
      
        else {
            
        
        
       for( medicine m: listmed){ 
           id=m.getId();
       }
         medicine med=new medicine(); 
      med.setCompany_name(txCompanyName.getText());
      med.setMedical_name(txScientificName.getText());
      med.setQuantity(txQuantity.getText());
      med.setExp(txExpirationDate.getText());
      med.setExp_after_open(txExpirationDateAfterOpening.getText());
      med.setOpening_date(txOpenDate.getText());
      med.setId(++id);
      med.setType("non");
      med.setUser_num(us.getPhone_num());
      med.setAdmin_num(num);
      System.out.println(med.getUser_num());
       
      med.setInserted_date(date);
      //med.setReceived_date("16/9/2019");

       Session session2 = HibernateUtil.getSessionFactory().openSession();
        session2 = HibernateUtil.getSessionFactory().openSession();
        Transaction tx4 = session2.beginTransaction();
        session2.save(med);
        tx4.commit();
        session2.close(); 
        }

      messageAccet.setVisible(true);
  
            }

    }  

     @FXML
    private void minimizeback(MouseEvent event) {
        back.setPrefHeight(back.getPrefHeight()-5);
        back.setPrefWidth(back.getPrefWidth()-5);
        back.setTranslateX(back.getTranslateX()+5);
    }

    @FXML
    private void enlargeback(MouseEvent event) {
        back.setPrefHeight(back.getPrefHeight()+5);
        back.setPrefWidth(back.getPrefWidth()+5);
        back.setTranslateX(back.getTranslateX()-5);
    }
    
    
     @FXML
    private void minimizesave(MouseEvent event) {
        btInser.setPrefHeight(btInser.getPrefHeight()-5);
        btInser.setPrefWidth(btInser.getPrefWidth()-5);
        btInser.setTranslateX(btInser.getTranslateX()+5);
    }

    @FXML
    private void enlargesave(MouseEvent event) {
        btInser.setPrefHeight(btInser.getPrefHeight()+5);
        btInser.setPrefWidth(btInser.getPrefWidth()+5);
        btInser.setTranslateX(btInser.getTranslateX()-5);
    }
  

}