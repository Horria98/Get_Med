/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_getmed;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.hibernate.Query;
import org.hibernate.Session;

import java.io.Serializable;
import java.util.List;
import javafx.event.ActionEvent;
import javafx.scene.layout.AnchorPane;
import org.hibernate.*;


public class Get_medController implements Initializable {
Session session = HibernateUtil.getSessionFactory().openSession();
    @FXML
    private Button btGet;
    @FXML
    private Text quantity1;
    @FXML
    private ImageView BACK;
  
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    } 
    
  
    
    @FXML
    private Text scientific_name;

    @FXML
    private Text company_name;

    @FXML
    private Text opening_date;

       @FXML
    private Text exipation_date;
    
    @FXML
    private Text quantity;

    @FXML
    private Text shelf_life_after_opening;
    
  @FXML
    private Text name;

    @FXML
    private Text phone;
  @FXML
    private AnchorPane pane_information;
  String prescription;

  medicine med_get=new medicine();
  int id;
 public void set_information(medicine m){
           this.med_get=m;
     
           med_get.setCompany_name(m.getCompany_name());
           med_get.setMedical_name(m.getMedical_name());
           med_get.setExp(m.getExp());
           med_get.setExp_after_open(m.getExp_after_open());
           med_get.setOpening_date(m.getOpening_date());
           med_get.setQuantity(m.getQuantity());
           med_get.setId(m.getId());
           med_get.setUser_num(m.getUser_num());
           
           med_get.setType(m.getType());
           med_get.setPrescription(m.getPrescription());
        
        
        scientific_name.setText(m.getMedical_name());  
        company_name.setText(m.getCompany_name());
        opening_date.setText(m.getOpening_date());
        exipation_date.setText(m.getExp());
        shelf_life_after_opening.setText(m.getExp_after_open());
        quantity.setText(m.getQuantity());
        
       }
  
            
                
           
               
              
               

 
   
   @FXML
    void homePage(javafx.scene.input.MouseEvent event) throws IOException {

     Parent aboutParent =FXMLLoader.load(getClass().getResource("Homepage.fxml"));
      Scene aboutScene=new Scene(aboutParent); 
      
   
     Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
     
     window.setScene(aboutScene);
    } 

 @FXML
    void show_inf(ActionEvent event) {
    id=med_get.getId();
    Session session1 = HibernateUtil.getSessionFactory().openSession();
        List<user_info> user_list = null;
        String queryStr = "from user_info";
        Query query = session1.createQuery(queryStr);
        user_list =  query.list();
        session1.close();
        for(user_info u: user_list){
        System.out.print(u.getPhone_num());
       int q =Integer.valueOf(quantity.getText());
        System.out.println(q);
        if(q==1)
         {
             btGet.setDisable(true);
             name.setText(u.getFull_name());
             phone.setText(u.getPhone_num());
             pane_information.setVisible(true);
             q--;
             quantity.setText(String.valueOf(q));
         Session session2=HibernateUtil.getSessionFactory().openSession();
          Transaction tx=session2.beginTransaction();
     
         session2.delete(med_get);
      
         tx.commit();
      
         session2.close();
         }
        else {
             btGet.setDisable(true);
             name.setText(u.getFull_name());
             phone.setText(u.getPhone_num());
             pane_information.setVisible(true);
             q--;
             quantity.setText(String.valueOf(q));  
        
         Session session2 = HibernateUtil.getSessionFactory().openSession(); session2.beginTransaction();
          medicine  s2 = null;
           s2 =(medicine)session2.get(medicine.class, id);
           s2.setQuantity(quantity.getText());
           session2.getTransaction().commit();
           session2.close();
         }
        }
         
         
    }}
    


