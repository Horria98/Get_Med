/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_getmed;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

 
@Entity
@Table(name="PRESCRIPTION")
public class prescription  implements java.io.Serializable {

     @Id
     @Column(name="serial_num")
     private int serial_num;
     @Column(name="photo")
     private byte[] photo;
     @Column(name="user_num")
     private String user_num;
     @Column(name="admin_num")
     private String admin_num;
     @Column(name="medicine_id")
     private int medicine_id;
     @Column (name="accept")
     private String accept;

     public prescription() {
    } 

    public prescription(int serial_num, byte[] photo, String user_num, String admin_num, int medicine_id , String accept) {
        this.serial_num = serial_num;
        this.photo = photo;
        this.user_num = user_num;
        this.admin_num = admin_num;
        this.medicine_id = medicine_id;
        this.accept = accept;
    }

    public void setAccept(String accept) {
        this.accept = accept;
    }

    public String getAccept() {
        return accept;
    }

    public int getSerial_num() {
        return serial_num;
    }

    public byte[] getPhoto() {
        return photo;
    }

    public String getUser_num() {
        return user_num;
    }

    public String getAdmin_num() {
        return admin_num;
    }

    public int getMedicine_id() {
        return medicine_id;
    }

    public void setSerial_num(int serial_num) {
        this.serial_num = serial_num;
    }

    public void setPhoto(byte[] photo) {
        this.photo = photo;
    }

    public void setUser_num(String user_num) {
        this.user_num = user_num;
    }

    public void setAdmin_num(String admin_number) {
        this.admin_num = admin_number;
    }

    public void setMedicine_id(int medicine_id) {
        this.medicine_id = medicine_id;
    }
     
}
