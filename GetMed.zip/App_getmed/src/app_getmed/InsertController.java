 
package app_getmed;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author QHPSLV
 */
public class InsertController implements Initializable {
 @FXML
    private Label lbScientificName;

    @FXML
    private Label lbCompanyName;

    @FXML
    private Label lbExpirationDate;

    @FXML
    private Label lbOpeningDate;

    @FXML
    private Label lbShelfLifeAfterOpening;

    @FXML
    private Label lbQuantity;

    @FXML
    private Button btInsert;
    @FXML
    private Button btBack;
    @FXML
    private ImageView back;
    @Override
    public void initialize(URL url, ResourceBundle rb) {  
  
        
        
    }    
    
     public void changeScenesnewMedication(ActionEvent event) throws IOException{
     Parent changeScenesInsert = FXMLLoader.load(getClass().getResource("newMedication.fxml"));
     Scene newMedicationScene =new Scene(changeScenesInsert);
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    window.setScene(newMedicationScene);
    window.show();
    }
    


   public void changeScenesHomepage (ActionEvent event) throws IOException{
     Parent changeScenesHomepage = FXMLLoader.load(getClass().getResource("Homepage.fxml"));
     Scene HomepageScene =new Scene( changeScenesHomepage);
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    window.setScene(HomepageScene);
    window.show();
    }    
    
      
  //هنا ضيفي الصفحة الشخصيةللتعديل
     public void changeScenesProfile (ActionEvent event) throws IOException{
     Parent changeScenesProfile  = FXMLLoader.load(getClass().getResource("Profile.fxml"));
     Scene ProfileScene =new Scene(changeScenesProfile);
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    window.setScene(ProfileScene);
    window.show();
    }
   
     
     
      


    @FXML
   public void changeSceneBACK (ActionEvent event) throws IOException{
      Parent changeScenesInsert = FXMLLoader.load(getClass().getResource("newMedication.fxml"));
     Scene newMedicationScene =new Scene(changeScenesInsert);
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    window.setScene(newMedicationScene);
    window.show();
    }    
    
   
   
    public void DisplayMedication(String ScientificName , String CompanyName, String ExpirationDate, String OpeningDate,String ShelfLifeAfterOpening,String Quantity ){
   
        lbScientificName.setText(ScientificName);
    
    
        lbCompanyName.setText(CompanyName);
    
        lbExpirationDate.setText(ExpirationDate);
    
       
        lbOpeningDate.setText(OpeningDate);
    
        lbShelfLifeAfterOpening.setText(ShelfLifeAfterOpening);
        
        lbQuantity.setText(Quantity);
        
    } 
    
    
    
    public void searchMedication(String ScientificName , String CompanyName){
      lbScientificName.setText(ScientificName);
      lbCompanyName.setText(CompanyName);
    
    }

    @FXML
    private void changeSceneBACK(MouseEvent event) {
    }
    
    @FXML
    private void minimizebtInsert(MouseEvent event) {
        btInsert.setPrefHeight(btInsert.getPrefHeight()-5);
        btInsert.setPrefWidth(btInsert.getPrefWidth()-5);
        btInsert.setTranslateX(btInsert.getTranslateX()+5);
    }

    @FXML
    private void enlargebtInsert(MouseEvent event) {
        btInsert.setPrefHeight(btInsert.getPrefHeight()+5);
        btInsert.setPrefWidth(btInsert.getPrefWidth()+5);
        btInsert.setTranslateX(btInsert.getTranslateX()-5);
    }
  
  @FXML
    private void minimizeback(MouseEvent event) {
        btBack.setPrefHeight(btBack.getPrefHeight()-5);
        btBack.setPrefWidth(btBack.getPrefWidth()-5);
        btBack.setTranslateX(btBack.getTranslateX()+5);
    }

    @FXML
    private void enlargeback(MouseEvent event) {
        btBack.setPrefHeight(btBack.getPrefHeight()+5);
        btBack.setPrefWidth(btBack.getPrefWidth()+5);
        btBack.setTranslateX(btBack.getTranslateX()-5);
    }
    

  
  
    
}
