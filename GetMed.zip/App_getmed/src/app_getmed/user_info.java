package app_getmed;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

 
@Entity
@Table(name="USER_INFO")
public class user_info  implements java.io.Serializable {

     @Id
     @Column(name="phone_num")
     private String phone_num;
     @Column(name="full_name")
     private String full_name;
     @Column(name="email")
     private String email;
     @Column(name="pass")
     private String pass;
     @Column(name="city")
     private String city;
     @Column(name="photo")
     private byte[] photo;

    public user_info() {
    }

    public user_info(String phone_num, String full_name, String email, String pass, String city, byte[] photo) {
        this.phone_num = phone_num;
        this.full_name = full_name;
        this.email = email;
        this.pass = pass;
        this.city = city;
        this.photo = photo;
    }

    public String getPhone_num() {
        return phone_num;
    }

    public String getFull_name() {
        return full_name;
    }

    public String getEmail() {
        return email;
    }

    public String getPass() {
        return pass;
    }

    public String getCity() {
        return city;
    }

    public byte[] getPhoto() {
        return photo;
    }

    public void setPhone_num(String phone_num) {
        this.phone_num = phone_num;
    }

    public void setFull_name(String full_name) {
        this.full_name = full_name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setPhoto(byte[] photo) {
        this.photo = photo;
    }


    


}


