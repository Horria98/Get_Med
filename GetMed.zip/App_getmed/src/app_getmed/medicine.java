/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_getmed;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

 
@Entity
@Table(name="MEDICINE")
public class medicine  implements java.io.Serializable {

    
   @Id
   @Column(name="id")
  private int id;
  
  @Column(name="company_name")
 private String company_name;
  
  @Column(name="medical_name")
 private  String medical_name ;
  
  @Column(name="Exp")
  private String Exp;
  
    @Column(name="quantity")
  private String quantity;
  
    @Column(name="opening_date")
  private String opening_date;
    
   
  @Column(name="Exp_after_open")
 private  String Exp_after_open ;
  
@Column(name="user_num")
  private String user_num;
  
    @Column(name="inserted_date")
  private String inserted_date;
  
    @Column(name="received_date")
  private String received_date;  
    
  @Column(name="admin_num")
  private String admin_num;
  
    @Column(name="photo")
  private byte[] photo;  
    
    @Column(name="type")
  private String type; 
   
    @Column(name="prescription")
  private String prescription;

    
    
  
    public medicine() {
    }

    public void setPrescription(String prescription) {
        this.prescription = prescription;
    }

    public String getPrescription() {
        return prescription;
    }
  
    

    public void setId(int id) {
        this.id = id;
    }

    public void setCompany_name(String company_name) {
        this.company_name = company_name;
    }

    public void setMedical_name(String medical_name) {
        this.medical_name = medical_name;
    }

    public void setExp(String Exp) {
        this.Exp = Exp;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public void setOpening_date(String opening_date) {
        this.opening_date = opening_date;
    }

    public void setExp_after_open(String Exp_after_open) {
        this.Exp_after_open = Exp_after_open;
    }

    public void setUser_num(String user_num) {
        this.user_num = user_num;
    }

    public void setInserted_date(String inserted_date) {
        this.inserted_date = inserted_date;
    }

    public void setReceived_date(String received_date) {
        this.received_date = received_date;
    }

    public void setAdmin_num(String admin_num) {
        this.admin_num = admin_num;
    }

    public void setPhoto(byte[] photo) {
        this.photo = photo;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getId() {
        return id;
    }

    public String getCompany_name() {
        return company_name;
    }

    public String getMedical_name() {
        return medical_name;
    }

    public String getExp() {
        return Exp;
    }

    public String getQuantity() {
        return quantity;
    }

    public String getOpening_date() {
        return opening_date;
    }

    public String getExp_after_open() {
        return Exp_after_open;
    }

    public String getUser_num() {
        return user_num;
    }

    public String getInserted_date() {
        return inserted_date;
    }

    public String getReceived_date() {
        return received_date;
    }

    public String getAdmin_num() {
        return admin_num;
    }

    public byte[] getPhoto() {
        return photo;
    }

    public String getType() {
        return type;
    }
    
     
     
    
}
