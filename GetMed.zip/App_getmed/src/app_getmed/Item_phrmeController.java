/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_getmed;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 * FXML Controller class
 *
 * @author Khulood Alyaf3Y
 */
public class Item_phrmeController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    } 
    
    
    @FXML
    private AnchorPane new_mwd_insert;

    @FXML
    private Label name_user;
    
     private prescription pr;
     
     MyLestiner2 mylitsener;
     
     @FXML
    void click_item(MouseEvent event) {

       mylitsener.onclickListener(pr);
    }
    
    public void setData(prescription p, MyLestiner2 mylitsener){
    
    this.pr=p;
    this.mylitsener=mylitsener;
    
Session session1 = HibernateUtil.getSessionFactory().openSession();
        List<user_info> user_list = null;
        String queryStr = "from user_info";
        Query query = session1.createQuery(queryStr);
        user_list =  query.list();
        session1.close();
        for(user_info u: user_list){
            if (pr.getUser_num().equals(u.getPhone_num()))
                name_user.setText(u.getFull_name());
        }
    
    
  
    }

    
}
