/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_getmed;



/**
 *
 * @author ghaida..
 */
public class medv {

    public void setName(String name) {
        this.name = name;
    }

    public void setImgscr(String imgscr) {
        this.imgscr = imgscr;
    }

    public void setColor(String color) {
        this.color = color;
    }
   private String name;
     private String imgscr;
       private String color;

    public String getName() {
        return name;
    }

    public String getImgscr() {
        return imgscr;
    }

    public String getColor() {
        return color;
    }
       
}
