/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_getmed;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

 
@Entity
@Table(name="ADMIN_INFO")
public class admin_info  implements java.io.Serializable {

     @Id
     @Column(name="phone_number")
     private String phone_number;
     @Column(name="full_name")
     private String full_name;
     @Column(name="email")
     private String email;
     @Column(name="pass")
     private String pass;
     @Column(name="city")
     private String city;
     @Column(name="photo")
     private byte[] photo;
     
     public admin_info() {
    }

    public admin_info(String phone_number, String full_name, String email, String pass, String city, byte[] photo) {
        this.phone_number = phone_number;
        this.full_name = full_name;
        this.email = email;
        this.pass = pass;
        this.city = city;
        this.photo = photo;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public String getFull_name() {
        return full_name;
    }

    public String getEmail() {
        return email;
    }

    public String getPass() {
        return pass;
    }

    public String getCity() {
        return city;
    }

    public byte[] getPhoto() {
        return photo;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public void setFull_name(String full_name) {
        this.full_name = full_name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setPhoto(byte[] photo) {
        this.photo = photo;
    }
     
}
