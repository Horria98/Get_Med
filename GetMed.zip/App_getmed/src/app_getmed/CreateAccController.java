package app_getmed;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;


/**
 * FXML Controller class
 *
 * @author horre
 */

public class CreateAccController implements Initializable {

    /**
     * Initializes the controller class.
     */    
    @FXML private ComboBox comboBox;    
    @FXML
    private RadioButton clientRadioButton ;
    @FXML
    private RadioButton pharmacistRadioButton ;
    @FXML
    private ToggleGroup toggleGroup ;    
    public PasswordField txt_hide_Password;
    public TextField txt_show_passwod;
    public ImageView openEye;
    public ImageView closeEye;
    String password;
    
    @FXML
    private TextField name;
    @FXML
    private TextField phone;
    @FXML
    private TextField email;
    @FXML
    private CheckBox agreeCheckBox;
    @FXML
    private Button create;
    @FXML
    private Label label1;
    
    public  void initialize(){
        txt_show_passwod.setVisible(false);
        openEye.setVisible(false);
    }
    @FXML
    public void hidePasswordOnAction(KeyEvent keyEvent) {
        password=txt_hide_Password.getText();
        txt_show_passwod.setText(password);
    }
    @FXML
    public void showPasswordOnAction(KeyEvent keyEvent) {
        password=txt_show_passwod.getText();
        txt_hide_Password.setText(password);
    }
    @FXML
    public void open_Eye_ClickOnAction(MouseEvent mouseEvent) {
        txt_show_passwod.setVisible(false);
        openEye.setVisible(false);
        closeEye.setVisible(true);
        txt_hide_Password.setVisible(true);
    }
    @FXML
    public void close_Eye_Click_OnAction(MouseEvent mouseEvent) {
        txt_show_passwod.setVisible(true);
        openEye.setVisible(true);
        closeEye.setVisible(false);
        txt_hide_Password.setVisible(false);
    }

    public PasswordField txt_hide_Password2;
    public TextField txt_show_passwod2;
    public ImageView openEye2;
    public ImageView closeEye2;
    String password2;    
        public  void initialize2(){
        txt_show_passwod2.setVisible(false);
        openEye2.setVisible(false);
    }
    @FXML
    public void hidePasswordOnAction2(KeyEvent keyEvent) {
        password2=txt_hide_Password2.getText();
        txt_show_passwod2.setText(password2);
    }
    @FXML
    public void showPasswordOnAction2(KeyEvent keyEvent) {
        password2=txt_show_passwod2.getText();
        txt_hide_Password2.setText(password2);
    }
    @FXML
    public void open_Eye_ClickOnAction2(MouseEvent mouseEvent) {
        txt_show_passwod2.setVisible(false);
        openEye2.setVisible(false);
        closeEye2.setVisible(true);
        txt_hide_Password2.setVisible(true);
    }
    @FXML
    public void close_Eye_Click_OnAction2(MouseEvent mouseEvent) {
        txt_show_passwod2.setVisible(true);
        openEye2.setVisible(true);
        closeEye2.setVisible(false);
        txt_hide_Password2.setVisible(false);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        comboBox.getItems().addAll("Makkah","Jeddah","Taif","Riyadh","Dammam","Madinah","Khobar","Dahran","Al-qassim","Jazan","Abha","Al-baha");
        toggleGroup = new ToggleGroup() ;
        this.pharmacistRadioButton.setToggleGroup(toggleGroup);
        this.clientRadioButton.setToggleGroup(toggleGroup);

    }

    private Stage stage;
    private Scene scene;
    private Parent root;
    
    @FXML
    public void toLogin(ActionEvent event) throws IOException {
        password=txt_hide_Password.getText();
        password2=txt_hide_Password2.getText();
        String domain = "";
        if (name.getText().isEmpty()||email.getText().isEmpty()||phone.getText().isEmpty()||comboBox.getValue().toString().isEmpty()||password.isEmpty()||password2.isEmpty())
            {
                label1.setVisible(true);
            }
  
        if (clientRadioButton.isSelected()&&agreeCheckBox.isSelected()){
            
            if (email.getText().contains("@")) {
            int index = email.getText().indexOf("@");
            domain = email.getText().substring(index);
            } 
            if( phone.getText().length() !=10){
                label1.setText("The length of Mobile number must be 10 digits");
                label1.setVisible(true);
            }else if ( password.length() < 8 )
            {
                label1.setText("Password length should be Exceed 8 digits");
                label1.setVisible(true);
                
            }else if (!(domain.equals("@gmail.com")) && !(domain.equals("@yahoo.com")) && !(domain.equals("@outlook.com")) && !(domain.equals("@hotmail.com")) && !(domain.equals("@st.uqu.edu.sa"))) 
            {
            label1.setText("Please enter a valid e-mail.");
            label1.setVisible(true);
            }else if (!(agreeCheckBox.isSelected())){
            label1.setText("You must Agree to the Terms and Privacy Policy.");
            label1.setVisible(true);
            }else if (password.equals(password2))
            {
                    Session session1 = HibernateUtil.getSessionFactory().openSession();
                    List<user_info> user_list = null;
                    String queryStr = "from user_info";
                    Query query = session1.createQuery(queryStr);
                    user_list =  query.list();
                    session1.close();
                for (user_info u : user_list) {
                    if(u.getEmail().equals(email.getText())){
                    label1.setText("The Email is already taken");
                    label1.setVisible(true);
                    return;
                    }else if(u.getPhone_num().equals(phone.getText())){
                    label1.setText("The phone number is already exsit");
                    label1.setVisible(true);
                    return;
                    }
                }
                
                user_info us = new user_info();
                us.setPhone_num(phone.getText());
                us.setFull_name(name.getText());
                us.setEmail(email.getText());
                us.setPass(txt_hide_Password.getText());
                us.setCity(comboBox.getValue().toString());
        
                Session session2 = HibernateUtil.getSessionFactory().openSession();
                session2 = HibernateUtil.getSessionFactory().openSession();
                Transaction tx = session2.beginTransaction();
                session2.save(us);
                tx.commit();
                session2.close();
                
                Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
                stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show(); 
                
            }else
            {
                label1.setText("Password not equal");
                label1.setVisible(true);
            }
        }
    
        if (pharmacistRadioButton.isSelected()&&agreeCheckBox.isSelected())
            {
            if (email.getText().contains("@")) {
            int index = email.getText().indexOf("@");
            domain = email.getText().substring(index);
            } 
            if( phone.getText().length() !=10){
                label1.setText("The length of Mobile number must be 10 digits");
                label1.setVisible(true);
            }else if ( password.length() < 8 )
            {
                label1.setText("Password length should be Exceed 8 digits");
                label1.setVisible(true);
                
            }else if (!(domain.equals("@gmail.com")) && !(domain.equals("@yahoo.com")) && !(domain.equals("@outlook.com")) && !(domain.equals("@hotmail.com")) && !(domain.equals("@st.uqu.edu.sa"))) 
            {
            label1.setText("Please enter a valid e-mail.");
            label1.setVisible(true);
            }else if (password.equals(password2))
            {
                    Session session3 = HibernateUtil.getSessionFactory().openSession();
                    List<admin_info> admin_list = null;
                    String queryStr = "from admin_info";
                    Query query = session3.createQuery(queryStr);
                    admin_list =  query.list();
                    session3.close();
                for (admin_info a : admin_list) {
                    if(a.getEmail().equals(email.getText())){
                    label1.setText("The Email is already taken");
                    label1.setVisible(true);
                    return;
                    }else if(a.getPhone_number().equals(phone.getText())){
                    label1.setText("The phone number is already exsit");
                    label1.setVisible(true);
                    return;
                    }
                }
                
                admin_info ad = new admin_info();
                ad.setPhone_number(phone.getText());
                ad.setFull_name(name.getText());
                ad.setEmail(email.getText());
                ad.setPass(txt_hide_Password.getText());
                ad.setCity(comboBox.getValue().toString());
        
                Session session4 = HibernateUtil.getSessionFactory().openSession();
                session4 = HibernateUtil.getSessionFactory().openSession();
                Transaction tx = session4.beginTransaction();
                session4.save(ad);
                tx.commit();
                session4.close();
                
                Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
                stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show(); 
                
            }else
            {
                label1.setText("Password not equal");
                label1.setVisible(true);
            }
        }
}                 

    @FXML
    public void toLogin2(MouseEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
     @FXML
    private void minimizeCreate(MouseEvent event) {
        create.setPrefHeight(create.getPrefHeight()-5);
        create.setPrefWidth(create.getPrefWidth()-5);
        create.setTranslateX(create.getTranslateX()+5);

    }

    @FXML
    private void enlargeCreate(MouseEvent event) {
        create.setPrefHeight(create.getPrefHeight()+5);
        create.setPrefWidth(create.getPrefWidth()+5);
        create.setTranslateX(create.getTranslateX()-5);
    } 

    
}
