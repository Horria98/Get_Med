 
package app_getmed;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

 
public class HomepageController implements Initializable {

   @FXML
    private Label num_notfcation;
   NotfcatinContrroler n=new NotfcatinContrroler();
   
   
   private user_info us = new user_info();
   
   
    @FXML
    private Button profil;
    @FXML
    private Button insert;
    @FXML
    private Button all;
    @FXML
    private Button alt;
    @FXML
    private Button info15;
    @FXML
    private Button info17;
    @FXML
    private Button info16;
    @FXML
    private Button toinfo3;
    @FXML
    private Button info14;
    @FXML
    private Button home;
    @FXML
    private Button bell;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
  
        
    }  
     public void getName(user_info user){
        this.us = user ;
        us.setFull_name(user.getFull_name());
        System.out.println(us.getFull_name());
        us.setPhone_num(user.getPhone_num());
        System.out.println(us.getPhone_num());
    }
 
     private Stage stage;
    private Scene scene;
    private Parent root;
    
    @FXML
    public void changeScenesnewMedication(ActionEvent event) throws IOException{
        
     FXMLLoader fxmlloader =new FXMLLoader();                    
     fxmlloader.setLocation(getClass().getResource("newMedication.fxml"));
     Parent root = fxmlloader.load();
     NewMedicationController nController =fxmlloader.getController();
     nController.getName(us);
     stage = (Stage)((Node)event.getSource()).getScene().getWindow();
     scene = new Scene(root);
     stage.setScene(scene);
     stage.show();

    }
    
   
    @FXML
     public void changeScenesViewAll(ActionEvent event) throws IOException{
     Parent changeScenesViewAll = FXMLLoader.load(getClass().getResource("ViewAll.fxml"));
     Scene ViewAllScene =new Scene(changeScenesViewAll);
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    window.setScene( ViewAllScene);
    window.show();
    }
    
    @FXML
     public void changeScenesProfile (ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("profile.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }//change Scenes to Profile page
    
     @FXML
     public void changeScenestoNotification (ActionEvent event) throws IOException{
    Parent changeScenesProfile  = FXMLLoader.load(getClass().getResource("Notfication_1.fxml"));
    Scene ProfileScene =new Scene(changeScenesProfile);
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    window.setScene(ProfileScene);
    window.show();
    }//change Scenes to Notification page
   
 @FXML
    void viewex1(MouseEvent event) throws IOException {
  Parent aboutParent =FXMLLoader.load(getClass().getResource("get_med_ex1.fxml"));
      Scene aboutScene=new Scene(aboutParent); 
      
   
     Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
     
     window.setScene(aboutScene);
    }
        
 @FXML
    void viewex2(MouseEvent event) throws IOException {
  Parent aboutParent =FXMLLoader.load(getClass().getResource("get_med_ex2.fxml"));
      Scene aboutScene=new Scene(aboutParent); 
      
   
     Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
     
     window.setScene(aboutScene);
    }  
    @FXML
    void viewex3(MouseEvent event) throws IOException {
  Parent aboutParent =FXMLLoader.load(getClass().getResource("get_med_ex3.fxml"));
      Scene aboutScene=new Scene(aboutParent); 
     Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
     window.setScene(aboutScene);
    }
    void logout(MouseEvent event) throws IOException {

        Parent aboutParent =FXMLLoader.load(getClass().getResource("Login.fxml"));
      Scene aboutScene=new Scene(aboutParent); 
      
   
     Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
     
     window.setScene(aboutScene);  
        
        
        
    }
    @FXML
    public void changeScenesHomepage (ActionEvent event) throws IOException{
     Parent changeScenesHomepage = FXMLLoader.load(getClass().getResource("Homepage.fxml"));
     Scene HomepageScene =new Scene( changeScenesHomepage);
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    window.setScene(HomepageScene);
    window.show();
    } 
    
    @FXML
    private void minimizebell(MouseEvent event) {
        bell.setPrefHeight(bell.getPrefHeight()-5);
        bell.setPrefWidth(bell.getPrefWidth()-5);
        bell.setTranslateX(bell.getTranslateX()+5);
    }

    @FXML
    private void enlargebell(MouseEvent event) {
        bell.setPrefHeight(bell.getPrefHeight()+5);
        bell.setPrefWidth(bell.getPrefWidth()+5);     
        bell.setTranslateX(bell.getTranslateX()-5);
    }

    @FXML
    private void toNotification(ActionEvent event) {
    }
    
    @FXML
      void Pain_relievers_Scene(MouseEvent event) throws IOException{
     Parent changeScenesHomepage = FXMLLoader.load(getClass().getResource("Pain_relievers.fxml"));
     Scene HomepageScene =new Scene( changeScenesHomepage);
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    window.setScene(HomepageScene);
    window.show();
    } 
     @FXML
    void Antibiotics_scene(MouseEvent event) throws IOException {
 Parent changeScenesHomepage = FXMLLoader.load(getClass().getResource("Antibiotics.fxml"));
     Scene HomepageScene =new Scene( changeScenesHomepage);
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    window.setScene(HomepageScene);
    window.show();
    }
    
     @FXML
    void Anti_allergic_skin_scene(MouseEvent event) throws IOException {

         Parent changeScenesHomepage = FXMLLoader.load(getClass().getResource("Anti_allergic_skin.fxml"));
     Scene HomepageScene =new Scene( changeScenesHomepage);
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    window.setScene(HomepageScene);
    window.show();
    }
    @FXML
    void Pressure_scene(MouseEvent event) throws IOException {

         Parent changeScenesHomepage = FXMLLoader.load(getClass().getResource("Pressure.fxml"));
     Scene HomepageScene =new Scene( changeScenesHomepage);
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    window.setScene(HomepageScene);
    window.show();
    }
}
