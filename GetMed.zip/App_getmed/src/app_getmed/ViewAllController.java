package app_getmed;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.stage.Stage;
import org.hibernate.Query;
import org.hibernate.Session;
import java.util.Arrays;

//Autocomplete
import org.controlsfx.control.textfield.AutoCompletionBinding;
import org.controlsfx.control.textfield.TextFields;
import java.util.HashSet;
import java.util.Set;
import javafx.scene.input.MouseEvent;

 

public class ViewAllController implements Initializable {


    @FXML
    private Label l1;
    
    @FXML
    private Button back;

    @FXML
    private Button profil;

    @FXML
    private Button home;

    @FXML
    private Button insert;

    @FXML
    private TextField tfSerch;
    
    @FXML
    private Label labelmsg;

    
    private Stage stage;
    private Scene scene;
    private Parent root;
    @FXML
    private ScrollPane scolar;

    @FXML
    private GridPane gridp;
 
        @FXML
    private AnchorPane searchPane;  
      
      @FXML
    private Button back1;
      
      @FXML
    private Button btSearch;


    @FXML
    private GridPane gridp1;
    
     MyListener3  myListener3;
   
    int id;
    //Autocomplete
    private AutoCompletionBinding<String>autoCompletionbinding;
   
    private String[]AutoComplete={"pandol","paracetamolExtra","Fevadol",
           "paracetamol","Aspirin","Voltaren","Augmentin","Centrum","Flutab","Catafast","Vitamin-B","Vitamin-D",
           "Vitamin-C","Feroglobin","Panadrex","Zink","Zinctron","Adol","Brufen","Lereca"};
    private Set<String>Suggestion=new HashSet<>(Arrays.asList(AutoComplete));
   
    
    
    //private List<medv> medv=new ArrayList<>();
    
    List<medicine> n_med=new ArrayList();
    //List<medicine> n_med2=new ArrayList();
       

//     private List<medv> getData(){
//      List<medv> medv=new ArrayList<>();
//     medv meds = null;
//     
//      meds =new medv();
//     meds.setName("panadol");
//     meds.setImgscr("/image/p3.png");
//     medv.add(meds);
//     
//    
//     return medv;
//     }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
     //Autocomplete
      TextFields.bindAutoCompletion(tfSerch, AutoComplete);    
     
    medicine new_med=new medicine();
          Session session1 = HibernateUtil.getSessionFactory().openSession();
        List<medicine> listmed = null;
     
        String queryStr = "from medicine";
        Query query = session1.createQuery(queryStr);
        listmed =  query.list();
        session1.close();
   
       for( medicine m: listmed){ 
           
        medicine medIn=new medicine(); 
           id=m.getId();
           
           medIn.setCompany_name(m.getCompany_name());
           medIn.setMedical_name(m.getMedical_name());
           medIn.setExp(m.getExp());
           medIn.setExp_after_open(m.getExp_after_open());
           medIn.setOpening_date(m.getOpening_date());
           medIn.setQuantity(m.getQuantity());
           medIn.setId(m.getId());
           medIn.setType(m.getType());
           medIn.setPrescription(m.getPrescription());
           medIn.setPhoto(m.getPhoto());
       n_med.add(medIn);
       
    }
       
       
       
       
     int col=0;
        int row=0;
        
        try{
        for (int i=0; i<n_med.size() ;i++){
            FXMLLoader fxmlLoader = new FXMLLoader();
            
            if(n_med.get(i).getType().equals("Pain relievers")|| n_med.get(i).getType().equals("Pressure") || n_med.get(i).getType().equals("Antibiotics") || n_med.get(i).getType().equals("Anti-allergic skin" )) {
               
            fxmlLoader.setLocation(getClass().getResource("newitem.fxml"));
             AnchorPane anchorPane=fxmlLoader.load();
            NewitemController itemController = fxmlLoader.getController();
            itemController.setData(n_med.get(i),myListener3);
            
          
           if(col==3){
           col=0;
           row++;
           }
            gridp.add(anchorPane,col++,row);
            //set grid width
            gridp.setMaxWidth(Region.USE_COMPUTED_SIZE);
             gridp.setPrefWidth(Region.USE_COMPUTED_SIZE);
            gridp.setMinWidth(Region.USE_PREF_SIZE);
           //set
             gridp.setMaxHeight(Region.USE_COMPUTED_SIZE);
            gridp.setPrefHeight(Region.USE_COMPUTED_SIZE);
            gridp.setMinHeight(Region.USE_PREF_SIZE);
            GridPane.setMargin(anchorPane, new Insets(10, 10, 10, 10));
        }}}
        catch(IOException ex){
        ex.printStackTrace();
        }
        
    
 }
    @FXML
    public void changeScenesnewMedication(ActionEvent event) throws IOException{
     Parent changeScenesInsert = FXMLLoader.load(getClass().getResource("newMedication.fxml"));
     Scene newMedicationScene =new Scene(changeScenesInsert);
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    window.setScene(newMedicationScene);
    window.show();
    }
    


    @FXML
   public void changeScenesHomepage (ActionEvent event) throws IOException{
     Parent changeScenesHomepage = FXMLLoader.load(getClass().getResource("Homepage.fxml"));
     Scene HomepageScene =new Scene( changeScenesHomepage);
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    window.setScene(HomepageScene);
    window.show();
    }    

 
    @FXML
     public void changeScenesProfile (ActionEvent event) throws IOException{
     Parent changeScenesProfile  = FXMLLoader.load(getClass().getResource("Profile.fxml"));
     Scene ProfileScene =new Scene(changeScenesProfile);
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    window.setScene(ProfileScene);
    window.show();
    }
 
        
public void Search() throws IOException{
     int col=0;
     int row=0;
        String s=tfSerch.getText();
        try{
        for (int i=0; i<n_med.size() ;i++){
            System.out.println("hhhhh");
            FXMLLoader fxmlLoader = new FXMLLoader();
         if(n_med.get(i).getType() != "non"&&n_med.get(i).getCompany_name().equalsIgnoreCase(tfSerch.getText())) { 
                 
                  System.out.println("hhhhh");
                 
            fxmlLoader.setLocation(getClass().getResource("newitem.fxml"));
             AnchorPane anchorPane=fxmlLoader.load();
            NewitemController itemController = fxmlLoader.getController();
            itemController.setData(n_med.get(i),myListener3);
            if(col==3){
           col=0;
           row++;
           }
                gridp1.add(anchorPane, col++, row);
                //set grid width
                gridp1.setMaxWidth(Region.USE_COMPUTED_SIZE);
                gridp1.setPrefWidth(Region.USE_COMPUTED_SIZE);
                gridp1.setMinWidth(Region.USE_PREF_SIZE);
                //set
                gridp1.setMaxHeight(Region.USE_COMPUTED_SIZE);
                gridp1.setPrefHeight(Region.USE_COMPUTED_SIZE);
                gridp1.setMinHeight(Region.USE_PREF_SIZE);
                GridPane.setMargin(anchorPane, new Insets(10, 10, 10, 10));
        }}}
        catch(IOException ex){
        ex.printStackTrace();}
      
searchPane.setVisible(true);        
 
}//SEARCH
     
     
     @FXML   
  public void homeBack(ActionEvent event) {
   searchPane.setVisible(false); 
}
  
@FXML
    private void minimizeback(MouseEvent event) {
        back.setPrefHeight(back.getPrefHeight()-5);
        back.setPrefWidth(back.getPrefWidth()-5);
        back.setTranslateX(back.getTranslateX()+5);
    }

    @FXML
    private void enlargeback(MouseEvent event) {
        back.setPrefHeight(back.getPrefHeight()+5);
        back.setPrefWidth(back.getPrefWidth()+5);
        back.setTranslateX(back.getTranslateX()-5);
    }
    
    @FXML
    private void minimizeback1(MouseEvent event) {
        back.setPrefHeight(back.getPrefHeight()-5);
        back.setPrefWidth(back.getPrefWidth()-5);
        back.setTranslateX(back.getTranslateX()+5);
    }

    @FXML
    private void enlargeback1(MouseEvent event) {
        back1.setPrefHeight(back1.getPrefHeight()+5);
        back1.setPrefWidth(back1.getPrefWidth()+5);
        back1.setTranslateX(back1.getTranslateX()-5);
    }
    
    @FXML
    private void minimizeSearch(MouseEvent event) {
        btSearch.setPrefHeight(btSearch.getPrefHeight()-5);
        btSearch.setPrefWidth(btSearch.getPrefWidth()-5);
        btSearch.setTranslateX(btSearch.getTranslateX()+5);
    }

    @FXML
    private void enlargeSearch(MouseEvent event) {
        btSearch.setPrefHeight(btSearch.getPrefHeight()+5);
        btSearch.setPrefWidth(btSearch.getPrefWidth()+5);
        btSearch.setTranslateX(btSearch.getTranslateX()-5);
    }

  
  
}   
         
      
        
  
        
        
 
     
     
    
     
     

