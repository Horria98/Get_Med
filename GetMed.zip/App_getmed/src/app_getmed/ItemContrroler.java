/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_getmed;

/**
 *
 * @author Khulood Alyaf3Y
 */


import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;


public class ItemContrroler implements Initializable{

    @FXML
    private Label label_tiltel;

    @FXML
    private ImageView img_date;

    @FXML
    private Text text_date;

    @FXML
    private ImageView img_time;

    @FXML
    private Text text_time;

    private Notfcation notfec; 
    
       private MyListener mylitsener;

    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
       
        
    }
    
    @FXML
    void click_item(MouseEvent event) {

       mylitsener.onclickListener(notfec);
    }
    
    public void setData(Notfcation notfec, MyListener mylitsener){
    
    this.notfec=notfec;
    this.mylitsener=mylitsener;
    label_tiltel.setText(notfec.getTitel());
    
    text_date.setText(notfec.getDate());
    
    text_time.setText(notfec.getTime());
 
    }



    
  
   
   
}
 
    