/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_getmed;

/**
 *
 * @author Khulood Alyaf3Y
 */
public class Notfcation {
    
    private String titel;
    private String time;
    private String date;
    private String srcimgTime;
    private String srcimgdate;
    private String name_user;
  private String phone_user;
    public void setName_user(String name_user) {
        this.name_user = name_user;
    }

    public void setPhone_user(String phone_user) {
        this.phone_user = phone_user;
    }

    public String getPhone_user() {
        return phone_user;
    }
    

    public void setName_med(String name_med) {
        this.name_med = name_med;
    }
    private String name_med;

    public String getName_user() {
        return name_user;
    }

    public String getName_med() {
        return name_med;
    }

    public void setTitel(String titel) {
        this.titel = titel;
    }

    public String getTitel() {
        return titel;
    }

    public String getTime() {
        return time;
    }

    public String getDate() {
        return date;
    }

    public String getSrcimgTime() {
        return srcimgTime;
    }

    public String getSrcimgdate() {
        return srcimgdate;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setSrcimgTime(String srcimgTime) {
        this.srcimgTime = srcimgTime;
    }

    public void setSrcimgdate(String srcimgdate) {
        this.srcimgdate = srcimgdate;
    }
   
   
    
    
    
   
}
