/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_getmed;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.prefs.Preferences;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.controlsfx.control.Notifications;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 * FXML Controller class
 *
 * @author horre
 */
public class LoginController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML private RadioButton clientRadioButton ;
    @FXML private RadioButton pharmacistRadioButton ;
    @FXML private ToggleGroup toggleGroup ;
    @FXML private CheckBox rememberCheckBox ;
    
    Preferences preferences;
    
    @FXML
    private TextField email;

    @FXML
    private TextField txt_show_passwod;
    private Label message;
    public PasswordField txt_hide_Password;
  
    public ImageView openEye;
    public ImageView closeEye;
    String password;
    @FXML
    private Label label1;
    private user_info user = new user_info();
    @FXML
    private Button LogIn;
    
    
    public  void initialize(){
        txt_show_passwod.setVisible(false);
        openEye.setVisible(false);
    }

    @FXML
    public void hidePasswordOnAction(KeyEvent keyEvent) {
        password=txt_hide_Password.getText();
        txt_show_passwod.setText(password);

    }

    @FXML
    public void showPasswordOnAction(KeyEvent keyEvent) {
        password=txt_show_passwod.getText();
        txt_hide_Password.setText(password);
    }

    @FXML
    public void open_Eye_ClickOnAction(MouseEvent mouseEvent) {
        txt_show_passwod.setVisible(false);
        openEye.setVisible(false);
        closeEye.setVisible(true);
        txt_hide_Password.setVisible(true);

    }

    @FXML
    public void close_Eye_Click_OnAction(MouseEvent mouseEvent) {
        txt_show_passwod.setVisible(true);
        openEye.setVisible(true);
        closeEye.setVisible(false);
        txt_hide_Password.setVisible(false);
    }    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
           
        toggleGroup = new ToggleGroup();
        this.pharmacistRadioButton.setToggleGroup(toggleGroup);
        this.clientRadioButton.setToggleGroup(toggleGroup);
        
        preferences = Preferences.userNodeForPackage(LoginController.class);
        if (preferences != null ) {
            if (preferences.get("email", null) != null && !preferences.get("email", null).isEmpty()){
                email.setText(preferences.get("email", null));
                txt_hide_Password.setText(preferences.get("txt_hide_Password", null));
            }
        }
        
//     Notifications notificationBulidar = Notifications.create()
//   .title("hi")
//             .text("how are you")
//             .graphic(null)
//             .hideAfter(Duration.seconds(5))
//             .position(Pos.TOP_LEFT)
//          .onAction(new EventHandler<ActionEvent>(){
//              
//         
//        @Override
//        public void handle(ActionEvent event){
//                 System.out.println("cliik");
//                 
//             }
//    
//    });
//            
//       notificationBulidar.showConfirm();
    }
    
    
    private Stage stage;
    private Scene scene;
    private Parent root;
    
    @FXML
    public void toNewPass(MouseEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("newPass.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void toHomePage(ActionEvent event) throws IOException {
            
        if (clientRadioButton.isSelected())
        {
            Session session = HibernateUtil.getSessionFactory().openSession();
            List<user_info> user_list = null;
            String queryStr = "from user_info";
            Query query = session.createQuery(queryStr);
            user_list =  query.list();
            session.close();
            for(user_info u: user_list){
                if(email.getText().equals(u.getEmail())&&txt_hide_Password.getText().equals(u.getPass())) {
                    
                    if (rememberCheckBox.isSelected()){
                        preferences.put("email", email.getText());
                        preferences.put("txt_hide_Password", txt_hide_Password.getText());
                    }else{
                        preferences.put("email", "");
                        preferences.put("txt_hide_Password", "");
                    }
                    
                }
                
            }
            
            if (email.getText().isEmpty()||txt_hide_Password.getText().isEmpty())
            {
                label1.setVisible(true);
            }else {
                boolean flag = false;
                            
                            for(user_info u: user_list){
                                //if user found 
                                if(u.getEmail().equals(email.getText())){ 
                                    flag =true;
                                    System.out.println(u.getFull_name());
                                    System.out.println(u.getEmail());
                                    System.out.println(u.getPhone_num());
                                    System.out.println(u.getCity());
                               
                                    
                                    if(txt_hide_Password.getText().equals(u.getPass())){
                                        /*Parent root = FXMLLoader.load(getClass().getResource("Homepage.fxml"));
                                        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                                        scene = new Scene(root);
                                        stage.setScene(scene);
                                        stage.show();*/
                                        user.setFull_name(u.getFull_name());
                                        user.setPhone_num(u.getPhone_num());
                                        userLogInNow.userLogIn = email.getText();
                                        System.out.println(userLogInNow.userLogIn +" log in now");
                                        
                                        FXMLLoader fxmlloader =new FXMLLoader();        
                                        fxmlloader.setLocation(getClass().getResource("Homepage.fxml"));
                                        Parent root = fxmlloader.load();
                                        HomepageController pContrroler =fxmlloader.getController();
                                        pContrroler.getName(user);
                                        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                                        scene = new Scene(root);
                                        stage.setScene(scene);
                                        stage.show();
                                        
                                        }
                                    else {
                                        label1.setText("Invalid password");
                                        label1.setVisible(true);
                                    }
                                    }
                            }
                            if (flag == false){
                                label1.setText("email not found in database");
                                label1.setVisible(true);
                            }
                        
                        }
        } else  if(pharmacistRadioButton.isSelected())
                {
                    rememberCheckBox.setDisable(true);
                    if (email.getText().isEmpty()||txt_hide_Password.getText().isEmpty())
                    {
                         label1.setVisible(true);
                    }else {
                            boolean flag = false;
                            Session session1 = HibernateUtil.getSessionFactory().openSession();
                            List<admin_info> admin_list = null;
                            String queryStr = "from admin_info";
                            Query query = session1.createQuery(queryStr);
                            admin_list =  query.list();
                            session1.close();
                            for(admin_info a: admin_list){
                                //if user found 
                                if(a.getEmail().equals(email.getText())){ flag =true;
                                    
                                    if(txt_hide_Password.getText().equals(a.getPass())){

                                        Parent root = FXMLLoader.load(getClass().getResource("Admin_profile.fxml"));
                                        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                                        scene = new Scene(root);
                                        stage.setScene(scene);
                                        stage.show();
                                        }
                                    else {
                                        label1.setText("Invalid password");
                                        label1.setVisible(true);
                                    }
                                    }
                            }
                            if (flag == false){
                                label1.setText("email not found in database");
                                label1.setVisible(true);
                            }                       
                        }
                }
        
    }                
    
    @FXML
    public void toCreateAcc(MouseEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("CreateAcc.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void minimizeLogIn(MouseEvent event) {
        LogIn.setPrefHeight(LogIn.getPrefHeight()-5);
        LogIn.setPrefWidth(LogIn.getPrefWidth()-5);
        LogIn.setTranslateX(LogIn.getTranslateX()+5);
    }

    @FXML
    private void enlargeLogIn(MouseEvent event) {
        LogIn.setPrefHeight(LogIn.getPrefHeight()+5);
        LogIn.setPrefWidth(LogIn.getPrefWidth()+5);
        LogIn.setTranslateX(LogIn.getTranslateX()-5);
    }
    
    
    
}
