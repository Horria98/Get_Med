/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_getmed;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author ghaida..
 */
public class AllmedgetController implements Initializable {

    @FXML
    private Button back;
    @FXML
    private Button bell;
      @FXML
    private Button home;
             @FXML
    private ScrollPane scolar;

    @FXML
    private GridPane gridp;
    
   private List<medv> medv=new ArrayList<>();
    @FXML
    private Button profil;
    @FXML
    private Button insert;
    

     private List<medv> getData(){
      List<medv> medv=new ArrayList<>();
     medv meds = null;
     for(int i=0;i < 7;i++){
     
     meds =new medv();
     meds.setName("catafast");
     meds.setImgscr("/image/b1.png");
     medv.add(meds);
     
     meds =new medv();
     meds.setName("flutab");
     meds.setImgscr("/image/b2.jpg");
     medv.add(meds);
     
     
     meds =new medv();
     meds.setName("centrum");
     meds.setImgscr("/image/p6.jpg");
     medv.add(meds);
     }
     return medv;
     }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        medv.addAll(getData());
        int col=0;
        int row=0;
        
        try{
        for (int i=0; i<medv.size() ;i++){
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("newitem.fxml"));
             AnchorPane anchorPane=fxmlLoader.load();
            New_itemController itemController = fxmlLoader.getController();
            itemController.setData(medv.get(i));
            
          
           if(col==3){
           col=0;
           row++;
           }
            gridp.add(anchorPane,col++,row);
            //set grid width
            gridp.setMaxWidth(Region.USE_COMPUTED_SIZE);
             gridp.setPrefWidth(Region.USE_COMPUTED_SIZE);
            gridp.setMinWidth(Region.USE_PREF_SIZE);
           //set
             gridp.setMaxHeight(Region.USE_COMPUTED_SIZE);
            gridp.setPrefHeight(Region.USE_COMPUTED_SIZE);
            gridp.setMinHeight(Region.USE_PREF_SIZE);
            GridPane.setMargin(anchorPane, new Insets(10, 10, 10, 10));
        }}
        catch(IOException ex){
        ex.printStackTrace();
        }
        
    } 
     private Stage stage;
    private Scene scene;
    private Parent root;
    
    @FXML
    public void toProfile(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("profile.fxml"));

        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        }   
    @FXML
         public void changeScenesnewMedication(ActionEvent event) throws IOException{
     Parent changeScenesInsert = FXMLLoader.load(getClass().getResource("newMedication.fxml"));
     Scene newMedicationScene =new Scene(changeScenesInsert);
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    window.setScene(newMedicationScene);
    window.show();
    }
    
    
    @FXML
     public void changeScenesProfile (ActionEvent event) throws IOException{
    Parent changeScenesProfile  = FXMLLoader.load(getClass().getResource("profile.fxml"));
    Scene ProfileScene =new Scene(changeScenesProfile);
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    window.setScene(ProfileScene);
    window.show();
    }
    @FXML
      public void changeSceneshome (ActionEvent event) throws IOException{
    Parent changeScenesProfile  = FXMLLoader.load(getClass().getResource("Homepage.fxml"));
    Scene ProfileScene =new Scene(changeScenesProfile);
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    window.setScene(ProfileScene);
    window.show();
    }
      
      @FXML
    private void minimizeback(MouseEvent event) {
        back.setPrefHeight(back.getPrefHeight()-5);
        back.setPrefWidth(back.getPrefWidth()-5);
        back.setTranslateX(back.getTranslateX()+5);
    }

    @FXML
    private void enlargeback(MouseEvent event) {
        back.setPrefHeight(back.getPrefHeight()+5);
        back.setPrefWidth(back.getPrefWidth()+5);
        back.setTranslateX(back.getTranslateX()-5);
    }
    
    @FXML
    private void minimizebell(MouseEvent event) {
        bell.setPrefHeight(bell.getPrefHeight()-5);
        bell.setPrefWidth(bell.getPrefWidth()-5);
        bell.setTranslateX(bell.getTranslateX()+5);
    }

    @FXML
    private void enlargebell(MouseEvent event) {
        bell.setPrefHeight(bell.getPrefHeight()+5);
        bell.setPrefWidth(bell.getPrefWidth()+5);     
        bell.setTranslateX(bell.getTranslateX()-5);
    }

    @FXML
    private void toNotification(ActionEvent event) {
    }
    
}
