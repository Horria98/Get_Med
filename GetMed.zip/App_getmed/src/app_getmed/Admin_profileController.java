/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_getmed;

import java.awt.image.BufferedImage;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javax.imageio.ImageIO;
import org.hibernate.Query;
import org.hibernate.Session;
/**
 * FXML Controller class
 *
 * @author horre
 */
public class Admin_profileController implements Initializable {


    @FXML
    private Circle userPhoto;
    @FXML
    private TextField adminName;
    @FXML
    private Button bt1;
    @FXML
    private Button bt3;
    @FXML
    private Button bt2;
    @FXML
    private Button logOut;
    
    public static admin_info admin ;
    private byte[] buffer;


    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        Session session1 = HibernateUtil.getSessionFactory().openSession();
        List<admin_info> admin_list = null;
        String queryStr = "from admin_info";
        Query query = session1.createQuery(queryStr);
        admin_list =  query.list();
        session1.close();
        for(admin_info a: admin_list){
            adminName.setText(a.getFull_name());  
            adminName.setDisable(true);
            if (a.getPhoto() != null)
            {
            FileOutputStream fos;
        try {
            fos = new FileOutputStream("output.jpg");
            fos.write(a.getPhoto());
            fos.close();
        } catch (IOException e) {

        }
        ImagePattern adminImagePattern = new ImagePattern(new Image("file:output.jpg"));
        userPhoto.setFill(adminImagePattern);

        }else{
                Image img = new Image("/app_getmed/image/user.png",false);
                userPhoto.setFill(new ImagePattern(img));
                }
        }
    }
    
    private Stage stage;
    private Scene scene;
    private Parent root;
      @FXML
   
    public void toNotification(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("notfication.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        }
    
    public void toProfileSetting(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Admin_profile_setting.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        }
    
    public void toNewMedicin(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Allnewmedeccept.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        }
    
    public void toPrescription(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("accept_new_med.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        }
    
    public void toLogin(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        }
    
      
     @FXML
    void user_move(MouseEvent e) throws IOException {
        
        
      Parent acceptParent =FXMLLoader.load(getClass().getResource("accept_new_med.fxml"));
      Scene acceptScene=new Scene(acceptParent); 
      
   
     Stage window = (Stage)((Node)e.getSource()).getScene().getWindow();
     
     window.setScene(acceptScene);

    }
    
    @FXML
    private void minimizelogOut(MouseEvent event) {
        logOut.setPrefHeight(logOut.getPrefHeight()-5);
        logOut.setPrefWidth(logOut.getPrefWidth()-5);
        logOut.setTranslateX(logOut.getTranslateX()+5);
    }

    @FXML
    private void enlargelogOut(MouseEvent event) {
        logOut.setPrefHeight(logOut.getPrefHeight()+5);
        logOut.setPrefWidth(logOut.getPrefWidth()+5);
        logOut.setTranslateX(logOut.getTranslateX()-5);
    }
    

    
}
