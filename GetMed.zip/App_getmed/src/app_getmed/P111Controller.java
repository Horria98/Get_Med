/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_getmed;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.imageio.ImageIO;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 * FXML Controller class
 *
 * @author ghaida..
 */
public class P111Controller implements Initializable {

    @FXML
    private TextField name;
    @FXML
    private TextField phone;
    @FXML
    private TextField email;
    @FXML
    private Button back;
    @FXML
    private Circle userPhoto;
    @FXML
    private Button save;
    @FXML
    private Button edit;
   @FXML
   private ComboBox comboBox;    
      
    @FXML
    private TextField txt_show_passwod;
    @FXML
    private PasswordField txt_hide_Password;
    @FXML
    private TextField txt_show_passwod2;
    @FXML
    private PasswordField txt_hide_Password2;
    @FXML
    private ImageView closeEye;
    @FXML
    private ImageView closeEye2;
    @FXML
    private ImageView openEye;
    @FXML
    private ImageView openEye2;
    String password;
    String password2;
    
    private user_info us = new user_info();

    private FileChooser filechooser = new FileChooser();
    private File filePath ;
    @FXML
    private Label label1;
    private byte[] buffer;
    
    @FXML 
    void upload_photo(ActionEvent event) throws FileNotFoundException { 
        
        File selectedImage = filechooser.showOpenDialog(stage);
        if (selectedImage != null) {
            buffer = new byte[(int) selectedImage.length()];
            try {

                FileInputStream inputStream = new FileInputStream(selectedImage);
                inputStream.read(buffer);
                inputStream.close();
                
                BufferedImage bufferedImage = ImageIO.read(selectedImage);
                Image image = SwingFXUtils.toFXImage(bufferedImage, null);
                userPhoto.setFill(new ImagePattern(image));

            } catch (IOException e) {
                Alert error = new Alert(Alert.AlertType.ERROR);
                error.setTitle("Something went wrong");
                error.setHeaderText(null);
                error.setContentText("Try again");
                error.show();
            }
    }
    }
    
    public  void initialize(){
        txt_show_passwod.setVisible(false);
        openEye.setVisible(false);
    }
    @FXML
    public void hidePasswordOnAction(KeyEvent keyEvent) {
        password=txt_hide_Password.getText();
        txt_show_passwod.setText(password);
    }
    @FXML
    public void showPasswordOnAction(KeyEvent keyEvent) {
        password=txt_show_passwod.getText();
        txt_hide_Password.setText(password);
    }
    @FXML
    public void open_Eye_ClickOnAction(MouseEvent mouseEvent) {
        txt_show_passwod.setVisible(false);
        openEye.setVisible(false);
        closeEye.setVisible(true);
        txt_hide_Password.setVisible(true);
    }
    @FXML
    public void close_Eye_Click_OnAction(MouseEvent mouseEvent) {
        txt_show_passwod.setVisible(true);
        openEye.setVisible(true);
        closeEye.setVisible(false);
        txt_hide_Password.setVisible(false);
    }

    
        public  void initialize2(){
        txt_show_passwod2.setVisible(false);
        openEye2.setVisible(false);
    }
    @FXML
    public void hidePasswordOnAction2(KeyEvent keyEvent) {
        password2=txt_hide_Password2.getText();
        txt_show_passwod2.setText(password2);
    }
    @FXML
    public void showPasswordOnAction2(KeyEvent keyEvent) {
        password2=txt_show_passwod2.getText();
        txt_hide_Password2.setText(password2);
    }
    @FXML
    public void open_Eye_ClickOnAction2(MouseEvent mouseEvent) {
        txt_show_passwod2.setVisible(false);
        openEye2.setVisible(false);
        closeEye2.setVisible(true);
        txt_hide_Password2.setVisible(true);
    }
    @FXML
    public void close_Eye_Click_OnAction2(MouseEvent mouseEvent) {
        txt_show_passwod2.setVisible(true);
        openEye2.setVisible(true);
        closeEye2.setVisible(false);
        txt_hide_Password2.setVisible(false);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        comboBox.getItems().addAll("Makkah","Jeddah","Taif","Riyadh","Dammam","Madinah","Khobar","Dahran","Al-qassim","Jazan","Abha","Al-baha");
        //Image img = new Image("/app_getmed/image/user.png",false);
        //userPhoto.setFill(new ImagePattern(img));
        
        Session session1 = HibernateUtil.getSessionFactory().openSession();
        List<user_info> user_list = null;
        String queryStr = "from user_info";
        Query query = session1.createQuery(queryStr);
        user_list =  query.list();
        session1.close();
        for(user_info u: user_list){
            if (userLogInNow.userLogIn.equals(u.getEmail())){
            name.setText(u.getFull_name());
            phone.setText(String.valueOf(u.getPhone_num()));
            email.setText(u.getEmail());
            comboBox.setValue(u.getCity());
            txt_show_passwod.setText(u.getPass());
            txt_show_passwod2.setText(u.getPass());
            txt_hide_Password.setText(u.getPass());
            txt_hide_Password2.setText(u.getPass());
            if (u.getPhoto() != null){
            FileOutputStream fos;
            try {
                fos = new FileOutputStream("output.jpg");
                fos.write(u.getPhoto());
                fos.close();
            } catch (IOException e) { }
        ImagePattern adminImagePattern = new ImagePattern(new Image("file:output.jpg"));
        userPhoto.setFill(adminImagePattern);
        }else{
               Image img = new Image("/app_getmed/image/user.png",false);
               userPhoto.setFill(new ImagePattern(img)); 
            }
            }
        }
    }    
    
    
    private Stage stage;
    private Scene scene;
    private Parent root;
    
    @FXML
    public void Sava(ActionEvent event) throws IOException {
        password=txt_hide_Password.getText();
        password2=txt_hide_Password2.getText();
        String domain = "";
        if (email.getText().contains("@")) {
            int index = email.getText().indexOf("@");
            domain = email.getText().substring(index);
            } 
            if (name.getText().isEmpty()||email.getText().isEmpty()||phone.getText().isEmpty()||comboBox.getValue().toString().isEmpty()||password.isEmpty()||password2.isEmpty())
            {
                label1.setVisible(true);
            }else if( phone.getText().length() !=10){
                label1.setText("The length of Mobile number must be 10 digits");
                label1.setVisible(true);
            }else if ( password.length() < 8 )
            {
                label1.setText("Password length should be Exceed 8 digits");
                label1.setVisible(true);
                
            }else if (!(domain.equals("@gmail.com")) && !(domain.equals("@yahoo.com")) && !(domain.equals("@outlook.com")) && !(domain.equals("@hotmail.com")) && !(domain.equals("@st.uqu.edu.sa"))) 
            {
            label1.setText("Please enter a valid e-mail.");
            label1.setVisible(true);
            }else if (password.equals(password2))
            {
                Session session1 = HibernateUtil.getSessionFactory().openSession();
                List<user_info> user_list = null;
                String queryStr = "from user_info";
                Query query = session1.createQuery(queryStr);
                user_list =  query.list();
                session1.close();
                for(user_info u: user_list){
                if (userLogInNow.userLogIn.equals(u.getEmail())){
                Session session2 = HibernateUtil.getSessionFactory().openSession();
                session2.beginTransaction();
                u.setFull_name(name.getText());
                u.setPhone_num(phone.getText());
                u.setEmail(email.getText());
                u.setCity(comboBox.getValue().toString());
                u.setPass(txt_hide_Password.getText());
                u.setPhoto(buffer);
                session2.update(u);
                session2.getTransaction().commit();
                session2.close();

                Parent root = FXMLLoader.load(getClass().getResource("profile.fxml"));
                stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
                }
            }       
    }
    }
    
    @FXML
    public void toProfile(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("profile.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        }
    
     @FXML
    private void minimizeback(MouseEvent event) {
        back.setPrefHeight(back.getPrefHeight()-5);
        back.setPrefWidth(back.getPrefWidth()-5);
        back.setTranslateX(back.getTranslateX()+5);
    }

    @FXML
    private void enlargeback(MouseEvent event) {
        back.setPrefHeight(back.getPrefHeight()+5);
        back.setPrefWidth(back.getPrefWidth()+5);
        back.setTranslateX(back.getTranslateX()-5);
    }
    
     @FXML
    private void minimizesave(MouseEvent event) {
        save.setPrefHeight(save.getPrefHeight()-5);
        save.setPrefWidth(save.getPrefWidth()-5);
        save.setTranslateX(save.getTranslateX()+5);
    }

    @FXML
    private void enlargesave(MouseEvent event) {
        save.setPrefHeight(save.getPrefHeight()+5);
        save.setPrefWidth(save.getPrefWidth()+5);
        save.setTranslateX(save.getTranslateX()-5);
    }
 
    
}