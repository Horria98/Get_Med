/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_getmed;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.ImagePattern;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.imageio.ImageIO;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 * FXML Controller class
 *
 * @author ghaida..
 */
public class AllnewmedecceptController implements Initializable {
   
    @FXML
    private TextField Edit_name;

    @FXML
    private TextField Edeit_nmeComany;

    @FXML
    private TextField EditQuantity;

    @FXML
    private TextField EditExpirationDate;

    @FXML
    private TextField EditOpenDate;

    @FXML
    private TextField tEditExpirationDateAfterOpening;

    @FXML
    private Button btAccept;

    @FXML
    private RadioButton rbYes;

    @FXML
    private RadioButton rbNo;

    @FXML
    private ComboBox<String> comboBoxType;

    @FXML
    private Button btUpload;

    private TextArea EditFilePath;

     @FXML
    private AnchorPane Edie_pane;

    @FXML
    private ImageView back;

    @FXML
    private ScrollPane scrollpan_new_med;

    @FXML
    private VBox vbox_notfaction;

    @FXML
    private AnchorPane inform_med;
    
    @FXML
    private Text Lb_id;
    @FXML
    private Text scientific_name1;

    @FXML
    private Text company_name1;

    @FXML
    private Text opening_date1;

    @FXML
    private Text quantity1;

    @FXML
    private Text shelf_life_after_opening1;

    @FXML
    private Text exipation_date1;

    @FXML
    private Text quantity11;

  public String name;
   String company_name;
   String Exp;
   String Exp_after_open;
   String open_date;
   String quantity;
    @FXML
    private Button btBack;
    @FXML
    private Button btBack1;
    @FXML
    private ImageView back1;
    @FXML
    private Button btBack2;
    @FXML
    private ImageView back2;
    @FXML
    private Label label1;
    
    private FileChooser filechooser = new FileChooser();
    private File filePath ;
    private byte[] buffer;
    String pathe;
    @FXML
    private Button btEdit;

    public void setName(String name) {
        this.name = name;
    }

    public void setCompany_name(String company_name) {
        this.company_name = company_name;
    }

    public void setExp(String Exp) {
        this.Exp = Exp;
    }

    public void setExp_after_open(String Exp_after_open) {
        this.Exp_after_open = Exp_after_open;
    }

    public void setOpen_date(String open_date) {
        this.open_date = open_date;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getName() {
        return name;
    }

    public String getCompany_name() {
        return company_name;
    }

    public String getExp() {
        return Exp;
    }

    public String getExp_after_open() {
        return Exp_after_open;
    }

    public String getOpen_date() {
        return open_date;
    }

    public String getQuantity() {
        return quantity;
    }
    
    public void setPathe(String pathe) {
        this.pathe = pathe;
    }

    public String getPathe() {
        return pathe;
    }
   
  private ToggleGroup tgRbYORN;   
   int id;
   String numOfAdmin ;
    
   
   private MyListener3 myListener3;
    
   List<medicine> n_med=new ArrayList();
   
   
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    
        comboBoxType.getItems().addAll("Pain relievers","Pressure","Antibiotics","Anti-allergic skin");
        
          Session session1 = HibernateUtil.getSessionFactory().openSession();
        List<medicine> listmed = null;
     
        String queryStr = "from medicine";
        Query query = session1.createQuery(queryStr);
        listmed =  query.list();
        session1.close();
   
       for( medicine m: listmed){ 
           
        medicine medIn=new medicine(); 
           id=m.getId();
           
           medIn.setCompany_name(m.getCompany_name());
           medIn.setMedical_name(m.getMedical_name());
           medIn.setExp(m.getExp());
           medIn.setExp_after_open(m.getExp_after_open());
           medIn.setOpening_date(m.getOpening_date());
           medIn.setQuantity(m.getQuantity());
           medIn.setId(m.getId());
           medIn.setType(m.getType());
           System.out.println(medIn.getType());
           n_med.add(medIn);
       }
     
  
        if(n_med.size()>0){
          
     set_messge(n_med.get(0));
             myListener3=new MyListener3() {
                 
                 @Override
                 public void onclickListener(medicine med) {
                    set_messge(med);
                      inform_med.setVisible(true);
                      
                      
                 }

             };     
        }
      try{  
         for(int i=0;i<n_med.size();i++)
        {
            FXMLLoader fxmlloader =new FXMLLoader();
            System.out.println(n_med.get(i).getType());
          if(n_med.get(i).getType().equals("non")){
        fxmlloader.setLocation(getClass().getResource("item3.fxml"));
        AnchorPane pan_not=fxmlloader.load();
           
        Item3Controller itemContrroler=fxmlloader.getController();
         
         itemContrroler.setDataMed(n_med.get(i),myListener3);
         
         vbox_notfaction.getChildren().add(pan_not);
          
          
        }}}
         catch (IOException ex) {
                Logger.getLogger(NotfcatinContrroler.class.getName()).log(Level.SEVERE, null, ex);
            }
      
    }
  
        
     private Stage stage;
    private Scene scene;
    private Parent root;
    @FXML
    void toEdet(ActionEvent event) throws IOException {
   
      Edit_name.setText(scientific_name1.getText());
      Edeit_nmeComany.setText(company_name1.getText());
      EditQuantity.setText(quantity1.getText());
      EditExpirationDate.setText(exipation_date1.getText());
     EditOpenDate.setText(opening_date1.getText());
      tEditExpirationDateAfterOpening.setText(shelf_life_after_opening1.getText());
      inform_med.setVisible(false);
      Edie_pane.setVisible(true);
    }
    @FXML
    public void toProfile(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Admin_profile.fxml"));

        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        }   
   
 public void set_messge(medicine m){
 
 scientific_name1.setText(m.getMedical_name());
 company_name1.setText(m.getCompany_name());
 opening_date1.setText(m.getOpening_date());
 quantity1.setText(m.getQuantity());
 shelf_life_after_opening1.setText(m.getExp_after_open());
 exipation_date1.setText(m.getExp());
 Lb_id.setText(String.valueOf(m.getId()));

 }
  @FXML
    void isAccept(ActionEvent event) throws IOException {

     int id_Edit;
     Session session = HibernateUtil.getSessionFactory().openSession();
        List<admin_info> admin_list = null;
        String queryStr = "from admin_info";
        Query query = session.createQuery(queryStr);
        admin_list =  query.list();
        session.close();
        for(admin_info a: admin_list){
            numOfAdmin = a.getPhone_number();
        }  
        medicine new_med=new medicine();
        Session session1 = HibernateUtil.getSessionFactory().openSession();
        List<medicine> listmed = null;
     
        String queryStr1 = "from medicine";
        Query query1 = session1.createQuery(queryStr1);
        listmed =  query1.list();
        session1.close();
   
       for( medicine m: listmed){ 
        if( Integer.valueOf(Lb_id.getText()) == m.getId()){
          id_Edit=Integer.valueOf(Lb_id.getText());
          
      Session session2=HibernateUtil.getSessionFactory().openSession();
      Transaction tx=session2.beginTransaction();
     
      session2.delete(m);
      
      tx.commit();
      
      session2.close();
      
      medicine med=new medicine();
     
        med.setCompany_name(Edeit_nmeComany.getText());
        med.setMedical_name(Edit_name.getText());
        med.setExp(EditExpirationDate.getText());
        med.setExp_after_open(tEditExpirationDateAfterOpening.getText());
        med.setQuantity(EditQuantity.getText());
        med.setOpening_date(EditOpenDate.getText());
        med.setId(id_Edit);
        med.setType(comboBoxType.getValue());
        med.setAdmin_num(m.getAdmin_num());
        med.setUser_num(m.getUser_num());
        med.setPhoto(buffer);
         
        if(rbYes.isSelected()){
        med.setPrescription("yes");
        }
        
         if(rbNo.isSelected()){
        med.setPrescription("no");
        }
        
        session2 = HibernateUtil.getSessionFactory().openSession();
        session2 = HibernateUtil.getSessionFactory().openSession();
        Transaction tx1 = session2.beginTransaction();
        session2.save(med);
        tx1.commit();
        session2.close();
        }}
       
       
    
        
        Edie_pane.setVisible(false); 
        
         Parent root = FXMLLoader.load(getClass().getResource("Admin_profile.fxml"));

        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        
        
    }
    
    
    
    @FXML
     public void RadioButton(){
    tgRbYORN=new ToggleGroup();
    this.rbYes.setToggleGroup(tgRbYORN);
    this.rbNo.setToggleGroup(tgRbYORN);
     }
    
     @FXML
      public void uploadMedicine (ActionEvent event){

          File selectedImage = filechooser.showOpenDialog(stage);
        if (selectedImage != null) {
            buffer = new byte[(int) selectedImage.length()];
            try {

                FileInputStream inputStream = new FileInputStream(selectedImage);
                inputStream.read(buffer);
                inputStream.close();
                
                setPathe(selectedImage.getAbsolutePath());
                label1.setText(selectedImage.getAbsolutePath());
                

            } catch (IOException e) {
                Alert error = new Alert(Alert.AlertType.ERROR);
                error.setTitle("Something went wrong");
                error.setHeaderText(null);
                error.setContentText("Try again");
                error.show();
            }
    }
    }
      
     @FXML
    private void minimizeback(MouseEvent event) {
        btBack.setPrefHeight(btBack.getPrefHeight()-5);
        btBack.setPrefWidth(btBack.getPrefWidth()-5);
        btBack.setTranslateX(btBack.getTranslateX()+5);
    }

    @FXML
    private void enlargeback(MouseEvent event) {
        btBack.setPrefHeight(btBack.getPrefHeight()+5);
        btBack.setPrefWidth(btBack.getPrefWidth()+5);
        btBack.setTranslateX(btBack.getTranslateX()-5);
    }
     @FXML
    private void minimizeback1(MouseEvent event) {
        btBack1.setPrefHeight(btBack1.getPrefHeight()-5);
        btBack1.setPrefWidth(btBack1.getPrefWidth()-5);
        btBack1.setTranslateX(btBack1.getTranslateX()+5);
    }

    @FXML
    private void enlargeback1(MouseEvent event) {
        btBack1.setPrefHeight(btBack1.getPrefHeight()+5);
        btBack1.setPrefWidth(btBack1.getPrefWidth()+5);
        btBack1.setTranslateX(btBack1.getTranslateX()-5);
    }
     @FXML
    private void minimizeback2(MouseEvent event) {
        btBack2.setPrefHeight(btBack2.getPrefHeight()-5);
        btBack2.setPrefWidth(btBack2.getPrefWidth()-5);
        btBack2.setTranslateX(btBack2.getTranslateX()+5);
    }

    @FXML
    private void enlargeback2(MouseEvent event) {
        btBack2.setPrefHeight(btBack2.getPrefHeight()+5);
        btBack2.setPrefWidth(btBack2.getPrefWidth()+5);
        btBack2.setTranslateX(btBack2.getTranslateX()-5);
    }
    
    @FXML
    private void minimizeEdit(MouseEvent event) {
        btEdit.setPrefHeight(btEdit.getPrefHeight()-5);
        btEdit.setPrefWidth(btEdit.getPrefWidth()-5);
        btEdit.setTranslateX(btEdit.getTranslateX()+5);
    }

    @FXML
    private void enlargeEdit(MouseEvent event) {
        btEdit.setPrefHeight(btEdit.getPrefHeight()+5);
        btEdit.setPrefWidth(btEdit.getPrefWidth()+5);
        btEdit.setTranslateX(btEdit.getTranslateX()-5);
    }
    
    @FXML
    private void minimizeUpload(MouseEvent event) {
        btUpload.setPrefHeight(btUpload.getPrefHeight()-5);
        btUpload.setPrefWidth(btUpload.getPrefWidth()-5);
        btUpload.setTranslateX(btUpload.getTranslateX()+5);
    }

    @FXML
    private void enlargeUpload(MouseEvent event) {
        btUpload.setPrefHeight(btUpload.getPrefHeight()+5);
        btUpload.setPrefWidth(btUpload.getPrefWidth()+5);
        btUpload.setTranslateX(btUpload.getTranslateX()-5);
    }
    
    @FXML
    private void minimizeAccept(MouseEvent event) {
        btAccept.setPrefHeight(btAccept.getPrefHeight()-5);
        btAccept.setPrefWidth(btAccept.getPrefWidth()-5);
        btAccept.setTranslateX(btAccept.getTranslateX()+5);
    }

    @FXML
    private void enlargeAccept(MouseEvent event) {
        btAccept.setPrefHeight(btAccept.getPrefHeight()+5);
        btAccept.setPrefWidth(btAccept.getPrefWidth()+5);
        btAccept.setTranslateX(btAccept.getTranslateX()-5);
    }

    @FXML
    private void changeSceneBACK(MouseEvent event) {
    }
    

}