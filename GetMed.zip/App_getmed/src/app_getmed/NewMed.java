/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_getmed;

import javax.persistence.Column;
import javax.persistence.Id;

/**
 *
 * @author Khulood Alyaf3Y
 */
public class NewMed {
    
 private String company_name;

 private  String medical_name ;

  private String Exp;

  private String quantity;
 
  private String opening_date;
    
   
 private  String Exp_after_open ;

  
  private String inserted_date;
  
   
  private String received_date;  
 
    
   
  private String type;    

    public void setCompany_name(String company_name) {
        this.company_name = company_name;
    }

    public void setMedical_name(String medical_name) {
        this.medical_name = medical_name;
    }

    public void setExp(String Exp) {
        this.Exp = Exp;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public void setOpening_date(String opening_date) {
        this.opening_date = opening_date;
    }

    public void setExp_after_open(String Exp_after_open) {
        this.Exp_after_open = Exp_after_open;
    }

    public void setInserted_date(String inserted_date) {
        this.inserted_date = inserted_date;
    }

    public void setReceived_date(String received_date) {
        this.received_date = received_date;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCompany_name() {
        return company_name;
    }

    public String getMedical_name() {
        return medical_name;
    }

    public String getExp() {
        return Exp;
    }

    public String getQuantity() {
        return quantity;
    }

    public String getOpening_date() {
        return opening_date;
    }

    public String getExp_after_open() {
        return Exp_after_open;
    }

    public String getInserted_date() {
        return inserted_date;
    }

    public String getReceived_date() {
        return received_date;
    }

    public String getType() {
        return type;
    }
    
}
