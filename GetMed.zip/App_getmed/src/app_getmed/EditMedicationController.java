
package  app_getmed;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

 
public class EditMedicationController implements Initializable {

    
  

   int id=0;
   
     @FXML
    private TextArea txFilePath;
     @FXML
    private Button back;

    @FXML
    private TextField txScientificName;

    @FXML
    private TextField txCompanyName;

    @FXML
    private TextField txQuantity;

    @FXML
    private TextField txExpirationDate;

    @FXML
    private TextField txOpenDate;

    @FXML
    private TextField txExpirationDateAfterOpening;

    @FXML
    private Button btAccept;

    @FXML
    private RadioButton rbYes;

    @FXML
    private RadioButton rbNo;

    @FXML
    private ComboBox comboBox;
    
  
    private ToggleGroup tgRbYORN;   
    @FXML
    private Button btUpload;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
comboBox.getItems().addAll("Pain relievers","Pressure","Antibiotics","Vitamins","Anti-allergic skin");
  

 }    
    
    
    public void Fill_text_Eedit( String n,String n_c,String Ex,String EX_Af_Op,String OP_Deat,String Q){
    
    txScientificName.setText(n);
    txCompanyName.setText(n_c);
    txQuantity.setText(Q);
    txExpirationDate.setText(Ex);
    txExpirationDateAfterOpening.setText(EX_Af_Op);
    txOpenDate.setText(OP_Deat);
    
    }
    
 @FXML
    public void toProfile(ActionEvent event) throws IOException {
        
        
        Parent root = FXMLLoader.load(getClass().getResource("Admin_profile.fxml"));

       Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
       Scene  scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        }   
    
    @FXML
     public void RadioButton(){
    tgRbYORN=new ToggleGroup();
    this.rbYes.setToggleGroup(tgRbYORN);
    this.rbNo.setToggleGroup(tgRbYORN);
     }
    
    
        
//هنا ارجع لصفحة التعديل 
     public void changeScenestoEdit (ActionEvent event) throws IOException{
     Parent changeScenesProfile  = FXMLLoader.load(getClass().getResource("medeccept1.fxml"));
     Scene ProfileScene =new Scene(changeScenesProfile);
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    window.setScene(ProfileScene);
    window.show();
    }
    
       @FXML
    void isAccept(ActionEvent event) throws IOException {

      /*  
        
         FXMLLoader fxmlloader =new FXMLLoader();
        
        fxmlloader.setLocation(getClass().getResource("newMedication.fxml"));
        
           
        NewMedicationController contr=fxmlloader.getController();
        
          
   //  Medicine med_new=contr.sendInfMed();
   //  getInfMed(med_new);
     
          Medicine new_med=new Medicine();
          Session session1 = HibernateUtil.getSessionFactory().openSession();
        List<Medicine> listmed = null;
     
        String queryStr = "from Medicine";
        Query query = session1.createQuery(queryStr);
        listmed =  query.list();
        session1.close();
       
        if(listmed.size()==0){
      Medicine med=new Medicine(); 
      med.setCompany_name(txCompanyName.getText());
      med.setMedical_name(txScientificName.getText());
      med.setQuantity(txQuantity.getText());
      med.setExp(txExpirationDate.getText());
      med.setOpening_date(txOpenDate.getText());
      med.setId(++id);
      med.setType("non");
       
      med.setInserted_date("20/3/2020");
      med.setReceived_date("16/9/2019");
   //   med.setUser_num(id);
  //    med.setAdmin_num(id);
     
       Session session2 = HibernateUtil.getSessionFactory().openSession();
        session2 = HibernateUtil.getSessionFactory().openSession();
        Transaction tx4 = session2.beginTransaction();
        session2.save(med);
        tx4.commit();
        session2.close();
        }
      
        else {
        
       for( Medicine m: listmed){ 
           id=m.getId();
       }
         Medicine med=new Medicine(); 
      med.setCompany_name(txCompanyName.getText());
      med.setMedical_name(txScientificName.getText());
      med.setQuantity(txQuantity.getText());
      med.setExp(txExpirationDate.getText());
      med.setOpening_date(txOpenDate.getText());
      med.setId(++id);
      med.setType("non");
       
      med.setInserted_date("20/3/2020");
      med.setReceived_date("16/9/2019");
   //   med.setUser_num(id);
  //    med.setAdmin_num(id);
     
       Session session2 = HibernateUtil.getSessionFactory().openSession();
        session2 = HibernateUtil.getSessionFactory().openSession();
        Transaction tx4 = session2.beginTransaction();
        session2.save(med);
        tx4.commit();
        session2.close();
        
        
        
        } */ 
        
    }
    
    public void getInfMed(medicine m){
    
   txCompanyName.setText( m.getCompany_name());
      txScientificName.setText(m.getMedical_name());
     txQuantity.setText( m.getQuantity());
      txExpirationDate.setText(m.getExp());
      txOpenDate.setText(m.getOpening_date());
     txExpirationDateAfterOpening.setText(m.getExp_after_open());
    
    
    }
    
    @FXML
      public void uploadMedicine (ActionEvent event){
    FileChooser fc= new FileChooser();  
    fc.setTitle("Download a prescription");
    fc.setInitialDirectory(new File(System.getProperty("user.home")));
    fc.getExtensionFilters().clear();
    fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Image Files","*.png","*.jpg","*.gif"));     
    File file=fc.showOpenDialog(null);
    if(file!=null){txFilePath.appendText(file.getAbsolutePath());}
    else {System.out.println("A Faile is invalid");}
    }
      
       @FXML
    private void minimizeback(MouseEvent event) {
        back.setPrefHeight(back.getPrefHeight()-5);
        back.setPrefWidth(back.getPrefWidth()-5);
        back.setTranslateX(back.getTranslateX()+5);
    }

    @FXML
    private void enlargeback(MouseEvent event) {
        back.setPrefHeight(back.getPrefHeight()+5);
        back.setPrefWidth(back.getPrefWidth()+5);
        back.setTranslateX(back.getTranslateX()-5);
    }
    
      @FXML
    private void minimizebtAccept(MouseEvent event) {
        btAccept.setPrefHeight(btAccept.getPrefHeight()-5);
        btAccept.setPrefWidth(btAccept.getPrefWidth()-5);
        btAccept.setTranslateX(btAccept.getTranslateX()+5);
    }

    @FXML
    private void enlargebtAccept(MouseEvent event) {
        btAccept.setPrefHeight(btAccept.getPrefHeight()+5);
        btAccept.setPrefWidth(btAccept.getPrefWidth()+5);
        btAccept.setTranslateX(btAccept.getTranslateX()-5);
    }
    
    @FXML
    private void minimizeUpload(MouseEvent event) {
        btUpload.setPrefHeight(btUpload.getPrefHeight()-5);
        btUpload.setPrefWidth(btUpload.getPrefWidth()-5);
        btUpload.setTranslateX(btUpload.getTranslateX()+5);
    }

    @FXML
    private void enlargeUpload(MouseEvent event) {
        btUpload.setPrefHeight(btUpload.getPrefHeight()+5);
        btUpload.setPrefWidth(btUpload.getPrefWidth()+5);
        btUpload.setTranslateX(btUpload.getTranslateX()-5);
    }
   
}
