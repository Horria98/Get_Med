/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_getmed;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author ghaida..
 */
public class New_itemController implements Initializable {

    @FXML
    private Button info1;

    @FXML
    private ImageView imgmed;

    @FXML
    private Label namemed;
    
    private medv meds;
    Infopill1Controller n;
    
    private Stage stage;
    private Scene scene;
    private Parent root;
    
    
   
    public void setData(medv meds){
        this.meds=meds;
       namemed.setText(meds.getName());
       Image imge=new Image(getClass().getResourceAsStream(meds.getImgscr()));
       
       imgmed.setImage(imge);
    }

    @FXML
    void toinfo1(ActionEvent event) throws IOException {
//        List<medv> medv=new ArrayList<>();
//     medv meds = null;
        for(int i=0;i < 7;i++){
        if(meds.getName()=="panadol"){
        
        Parent root = FXMLLoader.load(getClass().getResource("infopill3.fxml"));

        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        }
        else if(meds.getName()=="fevadol"){
            Parent root = FXMLLoader.load(getClass().getResource("infopill4.fxml"));

        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();}
       
        else if(meds.getName()=="augment"){
            Parent root = FXMLLoader.load(getClass().getResource("infopill5.fxml"));

        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();}
        
          else if(meds.getName()=="catafast"){
            Parent root = FXMLLoader.load(getClass().getResource("infopill1.fxml"));

        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();}
        
         else if(meds.getName()=="flutab"){
            Parent root = FXMLLoader.load(getClass().getResource("infopill2.fxml"));

        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();}
         else if(meds.getName()=="centrum"){
            Parent root = FXMLLoader.load(getClass().getResource("infopill6.fxml"));

        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();}
 
    }}
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }  
    
    /* public void medicineInfo(ActionEvent event) throws IOException{
     Parent changeScenesHomepage = FXMLLoader.load(getClass().getResource("get_med.fxml"));
     Scene HomepageScene =new Scene( changeScenesHomepage);
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    window.setScene(HomepageScene);
    window.show();
    }*/
    
}
