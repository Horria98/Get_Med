/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_getmed;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 * FXML Controller class
 *
 * @author Khulood Alyaf3Y
 */
public class Anti_allergic_skinController implements Initializable {

     @FXML
    private Label lbScientificName;

    @FXML
    private Label lbCompanyName;

  ;
    @FXML
    private VBox vbox;
    @FXML
    private Button profil;

    @FXML
    private Button home;

    @FXML
    private Button insert;

    @FXML
    private Button btFilter;
    @FXML
 private TextField tfSerch;
    //private AutoCompletionBinding<String>autoComplet;
     private Stage stage;
    private Scene scene;
    private Parent root;
           @FXML
    private ScrollPane scolar;

    @FXML
    private GridPane gridp;
    int id;
    
      MyListener3 myListener3;
    List<medicine> n_med=new ArrayList();


    @Override
    public void initialize(URL url, ResourceBundle rb) {
    
    
    medicine new_med=new medicine();
          Session session1 = HibernateUtil.getSessionFactory().openSession();
        List<medicine> listmed = null;
     
        String queryStr = "from medicine";
        Query query = session1.createQuery(queryStr);
        listmed =  query.list();
        session1.close();
   
       for( medicine m: listmed){ 
           
        medicine medIn=new medicine(); 
           id=m.getId();
           
           medIn.setCompany_name(m.getCompany_name());
           medIn.setMedical_name(m.getMedical_name());
           medIn.setExp(m.getExp());
           medIn.setExp_after_open(m.getExp_after_open());
           medIn.setOpening_date(m.getOpening_date());
           medIn.setQuantity(m.getQuantity());
           medIn.setId(m.getId());
           medIn.setType(m.getType());
           medIn.setPrescription(m.getPrescription());
           medIn.setPhoto(m.getPhoto());
       n_med.add(medIn);
       
    }
     int col=0;
        int row=0;
        
        try{
        for (int i=0; i<n_med.size() ;i++){
            FXMLLoader fxmlLoader = new FXMLLoader();
            
            if(n_med.get(i).getType().equals("Anti-allergic skin")) {
            fxmlLoader.setLocation(getClass().getResource("newitem.fxml"));
             AnchorPane anchorPane=fxmlLoader.load();
            NewitemController itemController = fxmlLoader.getController();
            itemController.setData(n_med.get(i),myListener3);
            
          
           if(col==3){
           col=0;
           row++;
           }
            gridp.add(anchorPane,col++,row);
            //set grid width
            gridp.setMaxWidth(Region.USE_COMPUTED_SIZE);
             gridp.setPrefWidth(Region.USE_COMPUTED_SIZE);
            gridp.setMinWidth(Region.USE_PREF_SIZE);
           //set
             gridp.setMaxHeight(Region.USE_COMPUTED_SIZE);
            gridp.setPrefHeight(Region.USE_COMPUTED_SIZE);
            gridp.setMinHeight(Region.USE_PREF_SIZE);
            GridPane.setMargin(anchorPane, new Insets(10, 10, 10, 10));
        }}}
        catch(IOException ex){
        ex.printStackTrace();
        }
    }
    public void changeScenesnewMedication(ActionEvent event) throws IOException{
     Parent changeScenesInsert = FXMLLoader.load(getClass().getResource("newMedication.fxml"));
     Scene newMedicationScene =new Scene(changeScenesInsert);
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    window.setScene(newMedicationScene);
    window.show();
    }
    


   public void changeScenesHomepage (ActionEvent event) throws IOException{
     Parent changeScenesHomepage = FXMLLoader.load(getClass().getResource("Homepage.fxml"));
     Scene HomepageScene =new Scene( changeScenesHomepage);
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    window.setScene(HomepageScene);
    window.show();
    }    
    
      
 
     public void changeScenesProfile (ActionEvent event) throws IOException{
     Parent changeScenesProfile  = FXMLLoader.load(getClass().getResource("Profile.fxml"));
     Scene ProfileScene =new Scene(changeScenesProfile);
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    window.setScene(ProfileScene);
    window.show();
    }
      
 
    
   
} 