/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_getmed;

import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 * FXML Controller class
 *
 * @author ghaida..
 */
public class ProfileController implements Initializable {
    
    @FXML
    private Button bell;
    @FXML
    private Circle userPhoto;
    @FXML
    private TextField userName;
    @FXML
    private Button bt1;
    @FXML
    private Button bt3;
    @FXML
    private Button bt2;
     @FXML
    private Button logOut;

     @FXML
    private Button back;
     
     String userNum;
     MyListener3 myListener3;
     
     @FXML
    private GridPane gridp;
     @FXML
    private AnchorPane allinsert;
     
    List<medicine> n_med=new ArrayList();
    @FXML
    private Button profil;
    @FXML
    private Button home;
    @FXML
    private ScrollPane scolar;
    @FXML
    private Button bell1;
    @FXML
    private Button insert;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        Session session1 = HibernateUtil.getSessionFactory().openSession();
        List<user_info> user_list = null;
        String queryStr = "from user_info";
        Query query = session1.createQuery(queryStr);
        user_list =  query.list();
        session1.close();
        for(user_info u: user_list){
            if (userLogInNow.userLogIn.equals(u.getEmail())){
            userName.setText(u.getFull_name());  
            userName.setDisable(true);
            userNum = u.getPhone_num();
            if (u.getPhoto() != null){
                FileOutputStream fos;
        try {
            fos = new FileOutputStream("output.jpg");
            fos.write(u.getPhoto());
            fos.close();
        } catch (IOException e) {

        }
        ImagePattern adminImagePattern = new ImagePattern(new Image("file:output.jpg"));
        userPhoto.setFill(adminImagePattern);
            }else {
                Image img = new Image("/app_getmed/image/user.png",false);
                userPhoto.setFill(new ImagePattern(img));
            }
            }
        }
        
//        Session session3 = HibernateUtil.getSessionFactory().openSession();
//        List<user_info> u_list = null;
//        String queryStr3 = "from user_info";
//        Query query3 = session3.createQuery(queryStr3);
//        user_list =  query3.list();
//        session3.close();
//        for(user_info us: u_list){
//            if (us.getFull_name().equals(userName.getText())){
//                userNum = us.getPhone_num();              
//            }    
//        }
        
        medicine new_med=new medicine();
         Session session2 = HibernateUtil.getSessionFactory().openSession();
        List<medicine> listmed = null;
     
        String queryStr2 = "from medicine";
        Query query2 = session2.createQuery(queryStr2);
        listmed =  query2.list();
        session2.close();
   
       for( medicine m: listmed){               
           
        medicine medIn=new medicine(); 
           
           medIn.setCompany_name(m.getCompany_name());
           medIn.setMedical_name(m.getMedical_name());
           medIn.setExp(m.getExp());
           medIn.setExp_after_open(m.getExp_after_open());
           medIn.setOpening_date(m.getOpening_date());
           medIn.setQuantity(m.getQuantity());
           medIn.setId(m.getId());
           medIn.setType(m.getType());
           medIn.setPrescription(m.getPrescription());
           medIn.setPhoto(m.getPhoto());
           medIn.setUser_num(m.getUser_num());
           medIn.setAdmin_num(m.getAdmin_num());
           n_med.add(medIn);
       }
       
       
     int col=0;
        int row=0;
        
        try{
        for (int i=0; i<n_med.size() ;i++){
            if (n_med.get(i).getPhoto() != null && n_med.get(i).getUser_num().equals(userNum)){
               System.out.println("Horria");
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("newitem.fxml"));
             AnchorPane anchorPane=fxmlLoader.load();
            NewitemController itemController = fxmlLoader.getController();
            itemController.setData(n_med.get(i),myListener3);
            
           if(col==3){
           col=0;
           row++;
           }
            gridp.add(anchorPane,col++,row);
            //set grid width
            gridp.setMaxWidth(Region.USE_COMPUTED_SIZE);
             gridp.setPrefWidth(Region.USE_COMPUTED_SIZE);
            gridp.setMinWidth(Region.USE_PREF_SIZE);
           //set
             gridp.setMaxHeight(Region.USE_COMPUTED_SIZE);
            gridp.setPrefHeight(Region.USE_COMPUTED_SIZE);
            gridp.setMinHeight(Region.USE_PREF_SIZE);
            GridPane.setMargin(anchorPane, new Insets(10, 10, 10, 10));
        }}}
        catch(IOException ex){
        ex.printStackTrace();
        }  
    } 
   
    
    private Stage stage;
    private Scene scene;
    private Parent root;
    
    
    
    @FXML
    public void toNotification(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("notfication.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        }
    
    @FXML
    public void toProfileSetting(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("p111.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        }
    
    @FXML
    public void toallMedicininsert(ActionEvent event) throws IOException {
         allinsert.setVisible(true);
        }
    
    @FXML
    public void toallMedicinget(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Allmedget.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        }
    
    @FXML
    public void toLogin(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        }
    
    @FXML
    public void changeScenesnewMedication(ActionEvent event) throws IOException{
     Parent changeScenesInsert = FXMLLoader.load(getClass().getResource("newMedication.fxml"));
     Scene newMedicationScene =new Scene(changeScenesInsert);
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    window.setScene(newMedicationScene);
    window.show();
    }
    
    
    @FXML
    public void changeScenesHomepage (ActionEvent event) throws IOException{
    Parent changeScenesHomepage = FXMLLoader.load(getClass().getResource("Homepage.fxml"));
    Scene HomepageScene =new Scene( changeScenesHomepage);
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    window.setScene(HomepageScene);
    window.show();
    }
    
    @FXML
     public void changeScenesProfile (ActionEvent event) throws IOException{
     allinsert.setVisible(false);
    }
     
    @FXML
    private void minimizeback(MouseEvent event) {
        back.setPrefHeight(back.getPrefHeight()-5);
        back.setPrefWidth(back.getPrefWidth()-5);
        back.setTranslateX(back.getTranslateX()+5);
    }

    @FXML
    private void enlargeback(MouseEvent event) {
        back.setPrefHeight(back.getPrefHeight()+5);
        back.setPrefWidth(back.getPrefWidth()+5);
        back.setTranslateX(back.getTranslateX()-5);
    }
    
     @FXML
    private void minimizelogOut(MouseEvent event) {
        logOut.setPrefHeight(logOut.getPrefHeight()-5);
        logOut.setPrefWidth(logOut.getPrefWidth()-5);
        logOut.setTranslateX(logOut.getTranslateX()+5);
    }

    @FXML
    private void enlargelogOut(MouseEvent event) {
        logOut.setPrefHeight(logOut.getPrefHeight()+5);
        logOut.setPrefWidth(logOut.getPrefWidth()+5);
        logOut.setTranslateX(logOut.getTranslateX()-5);
    }

     @FXML
    private void minimizebell(MouseEvent event) {
        bell.setPrefHeight(bell.getPrefHeight()-5);
        bell.setPrefWidth(bell.getPrefWidth()-5);
        bell.setTranslateX(bell.getTranslateX()+5);
    }

    @FXML
    private void enlargebell(MouseEvent event) {
        bell.setPrefHeight(bell.getPrefHeight()+5);
        bell.setPrefWidth(bell.getPrefWidth()+5);     
        bell.setTranslateX(bell.getTranslateX()-5);
    }
 
  
    
}
